import { getInitials, avatarColor, statusConfig, priorityConfig, cn } from '../../utils';

export const Avatar = ({ user, size = 'sm', className = '' }) => {
  const sizes = { xs: 'w-5 h-5 text-[10px]', sm: 'w-7 h-7 text-xs', md: 'w-9 h-9 text-sm', lg: 'w-12 h-12 text-base' };
  if (!user) return <div className={cn(sizes[size], 'rounded-full bg-slate-200', className)} />;
  return user.avatar_url
    ? <img src={user.avatar_url} alt={user.name} className={cn(sizes[size], 'rounded-full object-cover ring-1 ring-white', className)} />
    : <div className={cn(sizes[size], 'rounded-full flex items-center justify-center font-semibold text-white ring-1 ring-white', className)} style={{ background: avatarColor(user.name) }}>
        {getInitials(user.name)}
      </div>;
};

export const AvatarGroup = ({ users = [], max = 3, size = 'sm' }) => {
  const shown = users.slice(0, max);
  const rest = users.length - max;
  return (
    <div className="flex -space-x-1.5">
      {shown.map(u => <Avatar key={u.id} user={u} size={size} />)}
      {rest > 0 && <div className="w-7 h-7 rounded-full bg-slate-200 flex items-center justify-center text-xs font-medium text-slate-600 ring-1 ring-white">+{rest}</div>}
    </div>
  );
};

export const StatusBadge = ({ status, size = 'sm' }) => {
  const cfg = statusConfig[status] || statusConfig.todo;
  return (
    <span className={cn('inline-flex items-center gap-1 rounded font-medium', size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-sm', cfg.color)}>
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: cfg.dot }} />
      {cfg.label}
    </span>
  );
};

export const PriorityBadge = ({ priority, iconOnly = false }) => {
  const cfg = priorityConfig[priority] || priorityConfig.medium;
  if (iconOnly) return <span title={cfg.label}>{cfg.icon}</span>;
  return (
    <span className={cn('inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium', cfg.color)}>
      {cfg.icon} {cfg.label}
    </span>
  );
};

export const Spinner = ({ size = 'sm', className = '' }) => {
  const sizes = { xs: 'w-3 h-3', sm: 'w-4 h-4', md: 'w-6 h-6', lg: 'w-8 h-8' };
  return <svg className={cn('animate-spin text-blue-600', sizes[size], className)} fill="none" viewBox="0 0 24 24">
    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
  </svg>;
};

export const Skeleton = ({ className = '', lines = 1 }) => (
  <div className="space-y-2">
    {Array.from({ length: lines }).map((_, i) => <div key={i} className={cn('skeleton h-4', className)} />)}
  </div>
);

export const EmptyState = ({ icon, title, subtitle, action }) => (
  <div className="flex flex-col items-center justify-center py-16 text-center">
    <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center text-2xl mb-3">{icon}</div>
    <div className="text-sm font-medium text-slate-700 mb-1">{title}</div>
    {subtitle && <div className="text-xs text-slate-400 mb-4 max-w-xs">{subtitle}</div>}
    {action}
  </div>
);

export const Modal = ({ open, onClose, title, children, footer, size = 'md' }) => {
  if (!open) return null;
  const sizes = { sm: 'max-w-sm', md: 'max-w-lg', lg: 'max-w-2xl', xl: 'max-w-4xl' };
  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className={cn('modal', sizes[size], 'w-full animate-fade-in')} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200">
          <h2 className="text-base font-semibold text-slate-900">{title}</h2>
          <button onClick={onClose} className="p-1 rounded hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>
        <div className="p-5">{children}</div>
        {footer && <div className="flex items-center justify-end gap-2 px-5 py-4 border-t border-slate-200 bg-slate-50 rounded-b-xl">{footer}</div>}
      </div>
    </div>
  );
};

export const Dropdown = ({ trigger, items, align = 'left' }) => {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    const handler = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);
  return (
    <div className="relative" ref={ref}>
      <div onClick={() => setOpen(!open)}>{trigger}</div>
      {open && (
        <div className={cn('dropdown animate-slide-in', align === 'right' ? 'right-0' : 'left-0', 'top-full mt-1')}>
          {items.map((item, i) => item === 'divider'
            ? <div key={i} className="my-1 border-t border-slate-100" />
            : <div key={i} className={cn('dropdown-item', item.danger && 'text-red-600 hover:bg-red-50')} onClick={() => { item.onClick(); setOpen(false); }}>
                {item.icon && <span className="w-4 h-4 flex items-center justify-center">{item.icon}</span>}
                {item.label}
              </div>
          )}
        </div>
      )}
    </div>
  );
};

import { useState, useRef, useEffect } from 'react';
