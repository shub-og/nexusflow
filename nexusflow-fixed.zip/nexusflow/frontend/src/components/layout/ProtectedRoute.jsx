import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Spinner } from '../components/common';
import { AppLayout } from '../components/layout/AppLayout';

export function ProtectedRoute() {
  const { firebaseUser, loading } = useAuth();
  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <div className="flex flex-col items-center gap-3">
        <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">N</div>
        <Spinner size="md" />
      </div>
    </div>
  );
  if (!firebaseUser) return <Navigate to="/login" replace />;
  return <AppLayout><Outlet /></AppLayout>;
}

export function PublicRoute() {
  const { firebaseUser, loading } = useAuth();
  if (loading) return null;
  if (firebaseUser) return <Navigate to="/dashboard" replace />;
  return <Outlet />;
}
