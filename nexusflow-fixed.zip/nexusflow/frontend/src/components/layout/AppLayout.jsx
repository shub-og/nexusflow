import { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useNotifications } from '../../context/NotifContext';
import { Avatar } from '../common';
import { formatRelative, cn } from '../../utils';

const NAV = [
  { to: '/dashboard', icon: '📊', label: 'Dashboard' },
  { to: '/projects', icon: '📁', label: 'Projects' },
  { to: '/board', icon: '🗂️', label: 'Board' },
  { to: '/team', icon: '👥', label: 'Team' },
];

export function AppLayout({ children }) {
  const { user, logout, isAdmin } = useAuth();
  const { unreadCount, notifications, markAllRead } = useNotifications();
  const [notifOpen, setNotifOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-56 flex-shrink-0 bg-white border-r border-slate-200 flex flex-col">
        {/* Logo */}
        <div className="h-14 flex items-center px-4 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-blue-600 rounded flex items-center justify-center text-white font-bold text-sm">N</div>
            <span className="font-semibold text-slate-900 text-sm">NexusFlow</span>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
          <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider px-3 py-2">Main</div>
          {NAV.map(item => (
            <NavLink key={item.to} to={item.to} className={({ isActive }) => cn('sidebar-link', isActive && 'active')}>
              <span className="text-base leading-none">{item.icon}</span>
              <span>{item.label}</span>
            </NavLink>
          ))}

          {isAdmin && (
            <>
              <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider px-3 py-2 mt-4">Admin</div>
              <NavLink to="/admin" className={({ isActive }) => cn('sidebar-link', isActive && 'active')}>
                <span className="text-base">⚙️</span>
                <span>Settings</span>
              </NavLink>
            </>
          )}
        </nav>

        {/* User footer */}
        <div className="p-3 border-t border-slate-200">
          <div className="relative">
            <button onClick={() => setUserMenuOpen(!userMenuOpen)} className="flex items-center gap-2 w-full px-2 py-2 rounded hover:bg-slate-50 transition-colors">
              <Avatar user={user} size="sm" />
              <div className="flex-1 text-left min-w-0">
                <div className="text-xs font-medium text-slate-800 truncate">{user?.name}</div>
                <div className="text-[10px] text-slate-400 capitalize">{user?.role}</div>
              </div>
              <svg className="w-3 h-3 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
            </button>
            {userMenuOpen && (
              <div className="absolute bottom-full left-0 right-0 mb-1 bg-white border border-slate-200 rounded-lg shadow-dropdown py-1 z-50 animate-slide-in">
                <NavLink to="/profile" className="dropdown-item" onClick={() => setUserMenuOpen(false)}>👤 Profile</NavLink>
                <NavLink to="/settings" className="dropdown-item" onClick={() => setUserMenuOpen(false)}>⚙️ Settings</NavLink>
                <div className="my-1 border-t border-slate-100" />
                <button onClick={logout} className="w-full text-left dropdown-item text-red-600 hover:bg-red-50">🚪 Sign out</button>
              </div>
            )}
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Topbar */}
        <header className="h-14 bg-white border-b border-slate-200 flex items-center px-6 gap-4 flex-shrink-0">
          <PageBreadcrumb />
          <div className="ml-auto flex items-center gap-2">
            {/* Notification bell */}
            <div className="relative">
              <button onClick={() => setNotifOpen(!notifOpen)} className="relative p-2 rounded hover:bg-slate-100 transition-colors text-slate-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>
                {unreadCount > 0 && <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">{unreadCount > 9 ? '9+' : unreadCount}</span>}
              </button>
              {notifOpen && <NotifPanel notifications={notifications} onMarkAll={markAllRead} onClose={() => setNotifOpen(false)} />}
            </div>

            {/* Role badge */}
            <span className={cn('badge text-[10px]', isAdmin ? 'badge-blue' : 'badge-green')}>
              {user?.role?.toUpperCase()}
            </span>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-6">{children}</main>
      </div>
    </div>
  );
}

function PageBreadcrumb() {
  const location = useLocation();
  const parts = location.pathname.split('/').filter(Boolean);
  return (
    <nav className="flex items-center gap-1 text-sm text-slate-400">
      {parts.map((part, i) => (
        <span key={i} className="flex items-center gap-1">
          {i > 0 && <span>/</span>}
          <span className={cn('capitalize', i === parts.length - 1 && 'text-slate-800 font-medium')}>
            {part.replace(/-/g, ' ')}
          </span>
        </span>
      ))}
    </nav>
  );
}

function NotifPanel({ notifications, onMarkAll, onClose }) {
  const typeIcon = { task_assigned: '📋', task_due: '⚠️', task_commented: '💬', project_invite: '📁', overdue_reminder: '🔴' };
  return (
    <div className="absolute right-0 top-full mt-1 w-80 bg-white border border-slate-200 rounded-xl shadow-dropdown z-50 animate-slide-in">
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100">
        <span className="text-sm font-semibold text-slate-900">Notifications</span>
        <button onClick={onMarkAll} className="text-xs text-blue-600 hover:underline">Mark all read</button>
      </div>
      <div className="max-h-80 overflow-y-auto divide-y divide-slate-50">
        {notifications.length === 0
          ? <div className="py-8 text-center text-sm text-slate-400">All caught up! 🎉</div>
          : notifications.slice(0, 10).map(n => (
              <div key={n.id} className={cn('flex gap-3 px-4 py-3 hover:bg-slate-50 transition-colors', !n.is_read && 'bg-blue-50/50')}>
                <span className="text-lg flex-shrink-0">{typeIcon[n.type] || '🔔'}</span>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium text-slate-800">{n.title}</div>
                  <div className="text-xs text-slate-500 mt-0.5 line-clamp-2">{n.message}</div>
                  <div className="text-[10px] text-slate-400 mt-1">{formatRelative(n.created_at)}</div>
                </div>
                {!n.is_read && <div className="w-2 h-2 rounded-full bg-blue-500 mt-1 flex-shrink-0" />}
              </div>
            ))
        }
      </div>
    </div>
  );
}
