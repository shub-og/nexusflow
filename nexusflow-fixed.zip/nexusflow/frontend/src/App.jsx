import { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './context/AuthContext';
import { NotifProvider } from './context/NotifContext';
import { ProtectedRoute, PublicRoute } from './components/layout/ProtectedRoute';
import { Spinner } from './components/common';
import './styles/globals.css';

// Lazy load pages for performance
const LandingPage    = lazy(() => import('./pages/landing/LandingPage'));
const LoginPage      = lazy(() => import('./pages/auth/AuthPages').then(m => ({ default: m.LoginPage })));
const SignupPage     = lazy(() => import('./pages/auth/AuthPages').then(m => ({ default: m.SignupPage })));
const DashboardPage  = lazy(() => import('./pages/dashboard/DashboardPage'));
const ProjectsPage   = lazy(() => import('./pages/projects/ProjectsPage'));
const ProjectDetailPage = lazy(() => import('./pages/projects/ProjectDetailPage'));
const BoardPage      = lazy(() => import('./pages/tasks/BoardPage'));
const TeamPage       = lazy(() => import('./pages/team/TeamPage'));

const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center bg-white">
    <div className="flex flex-col items-center gap-3">
      <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold text-lg">N</div>
      <Spinner size="md" />
      <p className="text-xs text-slate-400">Loading NexusFlow...</p>
    </div>
  </div>
);

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <NotifProvider>
          <Suspense fallback={<PageLoader />}>
            <Routes>
              {/* Landing page — always public */}
              <Route path="/" element={<LandingPage />} />

              {/* Auth routes — redirect to dashboard if already logged in */}
              <Route element={<PublicRoute />}>
                <Route path="/login"  element={<LoginPage />} />
                <Route path="/signup" element={<SignupPage />} />
              </Route>

              {/* Protected app routes */}
              <Route element={<ProtectedRoute />}>
                <Route path="/dashboard"       element={<DashboardPage />} />
                <Route path="/projects"        element={<ProjectsPage />} />
                <Route path="/projects/:id"    element={<ProjectDetailPage />} />
                <Route path="/board"           element={<BoardPage />} />
                <Route path="/team"            element={<TeamPage />} />
              </Route>

              {/* Catch-all */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </Suspense>

          <Toaster
            position="bottom-right"
            toastOptions={{
              duration: 3000,
              style: {
                fontSize: 13,
                borderRadius: 8,
                border: '1px solid #e2e8f0',
                boxShadow: '0 4px 12px rgba(0,0,0,.1)',
              },
              success: { iconTheme: { primary: '#16a34a', secondary: '#fff' } },
              error:   { iconTheme: { primary: '#dc2626', secondary: '#fff' } },
            }}
          />
        </NotifProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
