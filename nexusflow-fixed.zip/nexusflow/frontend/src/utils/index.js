import { formatDistanceToNow, format, isPast, isToday, isTomorrow } from 'date-fns';

export const formatDate = (date) => {
  if (!date) return null;
  return format(new Date(date), 'MMM d, yyyy');
};

export const formatRelative = (date) => {
  if (!date) return '';
  return formatDistanceToNow(new Date(date), { addSuffix: true });
};

export const formatDue = (date) => {
  if (!date) return null;
  const d = new Date(date);
  if (isToday(d)) return 'Today';
  if (isTomorrow(d)) return 'Tomorrow';
  if (isPast(d)) return `${format(d, 'MMM d')} (overdue)`;
  return format(d, 'MMM d');
};

export const isOverdue = (date, status) => {
  if (!date || status === 'done' || status === 'cancelled') return false;
  return isPast(new Date(date));
};

export const statusConfig = {
  todo: { label: 'To Do', color: 'bg-slate-100 text-slate-600', dot: '#64748b', border: 'border-slate-300' },
  in_progress: { label: 'In Progress', color: 'bg-blue-50 text-blue-700', dot: '#2563eb', border: 'border-blue-300' },
  in_review: { label: 'In Review', color: 'bg-purple-50 text-purple-700', dot: '#7c3aed', border: 'border-purple-300' },
  done: { label: 'Done', color: 'bg-green-50 text-green-700', dot: '#16a34a', border: 'border-green-300' },
  cancelled: { label: 'Cancelled', color: 'bg-red-50 text-red-600', dot: '#dc2626', border: 'border-red-300' },
};

export const priorityConfig = {
  critical: { label: 'Critical', color: 'text-red-600 bg-red-50', icon: '🔴', dot: '#dc2626' },
  high: { label: 'High', color: 'text-orange-600 bg-orange-50', icon: '🔶', dot: '#ea580c' },
  medium: { label: 'Medium', color: 'text-yellow-600 bg-yellow-50', icon: '🔷', dot: '#ca8a04' },
  low: { label: 'Low', color: 'text-green-600 bg-green-50', icon: '🔽', dot: '#16a34a' },
};

export const getInitials = (name = '') => {
  return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
};

export const avatarColor = (name = '') => {
  const colors = ['#2563eb', '#7c3aed', '#db2777', '#dc2626', '#ea580c', '#16a34a', '#0891b2'];
  let hash = 0;
  for (const c of name) hash = c.charCodeAt(0) + ((hash << 5) - hash);
  return colors[Math.abs(hash) % colors.length];
};

export const fileIcon = (mimetype = '') => {
  if (mimetype.startsWith('image/')) return '🖼️';
  if (mimetype === 'application/pdf') return '📄';
  if (mimetype.includes('word')) return '📝';
  if (mimetype.includes('sheet') || mimetype.includes('excel')) return '📊';
  if (mimetype.includes('zip')) return '🗜️';
  return '📎';
};

export const formatBytes = (bytes) => {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1024 / 1024).toFixed(1) + ' MB';
};

export const cn = (...classes) => classes.filter(Boolean).join(' ');
