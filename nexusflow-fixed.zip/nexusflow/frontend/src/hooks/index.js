import { useState, useEffect, useCallback, useRef } from 'react';
import { apiGet, apiPost, apiPut, apiDelete, apiPatch } from '../services/api';
import { getSocket } from '../services/socket';
import toast from 'react-hot-toast';

// ── useProjects ────────────────────────────────────────────────────────────────
export const useProjects = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetch = useCallback(async () => {
    try {
      setLoading(true);
      const data = await apiGet('/projects');
      setProjects(data.projects);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to load projects');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  const create = async (data) => {
    const res = await apiPost('/projects', data);
    setProjects(prev => [res.project, ...prev]);
    toast.success('Project created');
    return res.project;
  };

  const update = async (id, data) => {
    const res = await apiPut(`/projects/${id}`, data);
    setProjects(prev => prev.map(p => p.id === id ? res.project : p));
    toast.success('Project updated');
    return res.project;
  };

  const remove = async (id) => {
    await apiDelete(`/projects/${id}`);
    setProjects(prev => prev.filter(p => p.id !== id));
    toast.success('Project deleted');
  };

  const addMember = async (projectId, userId, role = 'member') => {
    const res = await apiPost(`/projects/${projectId}/members`, { user_id: userId, role });
    toast.success(res.message);
    fetch();
    return res;
  };

  const removeMember = async (projectId, userId) => {
    await apiDelete(`/projects/${projectId}/members/${userId}`);
    toast.success('Member removed');
    fetch();
  };

  return { projects, loading, error, fetch, create, update, remove, addMember, removeMember };
};

// ── useTasks ──────────────────────────────────────────────────────────────────
export const useTasks = (filters = {}) => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const filterRef = useRef(filters);

  const fetch = useCallback(async (overrideFilters) => {
    try {
      setLoading(true);
      const params = overrideFilters || filterRef.current;
      const data = await apiGet('/tasks', params);
      setTasks(data.tasks);
    } catch (err) {
      toast.error('Failed to load tasks');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  // Socket: real-time task updates
  useEffect(() => {
    const socket = getSocket();
    if (!socket) return;

    const onCreated = (task) => setTasks(prev => {
      if (prev.find(t => t.id === task.id)) return prev;
      return [task, ...prev];
    });
    const onUpdated = (task) => setTasks(prev => prev.map(t => t.id === task.id ? { ...t, ...task } : t));
    const onDeleted = ({ id }) => setTasks(prev => prev.filter(t => t.id !== id));

    socket.on('task:created', onCreated);
    socket.on('task:updated', onUpdated);
    socket.on('task:deleted', onDeleted);
    return () => {
      socket.off('task:created', onCreated);
      socket.off('task:updated', onUpdated);
      socket.off('task:deleted', onDeleted);
    };
  }, []);

  const create = async (data) => {
    const res = await apiPost('/tasks', data);
    toast.success('Task created');
    return res.task;
  };

  const update = async (id, data) => {
    const res = await apiPut(`/tasks/${id}`, data);
    setTasks(prev => prev.map(t => t.id === id ? { ...t, ...res.task } : t));
    return res.task;
  };

  const updateStatus = async (id, status) => {
    const res = await apiPut(`/tasks/${id}`, { status });
    setTasks(prev => prev.map(t => t.id === id ? { ...t, status } : t));
    toast.success(`Moved to ${status.replace('_', ' ')}`);
    return res.task;
  };

  const remove = async (id) => {
    await apiDelete(`/tasks/${id}`);
    setTasks(prev => prev.filter(t => t.id !== id));
    toast.success('Task deleted');
  };

  const reorder = async (reorderData) => {
    await apiPatch('/tasks/reorder', { tasks: reorderData });
  };

  return { tasks, setTasks, loading, fetch, create, update, updateStatus, remove, reorder };
};

// ── useDashboard ──────────────────────────────────────────────────────────────
export const useDashboard = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetch = useCallback(async () => {
    try {
      setLoading(true);
      const res = await apiGet('/dashboard');
      setData(res);
    } catch {
      toast.error('Failed to load dashboard');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  return { data, loading, refresh: fetch };
};

// ── useDebounce ───────────────────────────────────────────────────────────────
export const useDebounce = (value, delay = 300) => {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
};
