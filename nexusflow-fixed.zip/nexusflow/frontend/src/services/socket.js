import { io } from 'socket.io-client';
import { auth } from './firebase';

let socket = null;

export const connectSocket = async () => {
  if (socket?.connected) return socket;

  const user = auth.currentUser;
  if (!user) return null;

  const token = await user.getIdToken();

  socket = io(import.meta.env.VITE_SOCKET_URL || 'http://localhost:5000', {
    auth: { token },
    transports: ['websocket', 'polling'],
    reconnection: true,
    reconnectionDelay: 1000,
    reconnectionAttempts: 5,
  });

  socket.on('connect', () => console.log('🔌 Socket connected:', socket.id));
  socket.on('disconnect', (reason) => console.log('🔌 Socket disconnected:', reason));
  socket.on('connect_error', (err) => console.error('🔌 Socket error:', err.message));

  return socket;
};

export const getSocket = () => socket;

export const disconnectSocket = () => {
  socket?.disconnect();
  socket = null;
};

export const joinProject = (projectId) => socket?.emit('join:project', projectId);
export const leaveProject = (projectId) => socket?.emit('leave:project', projectId);
export const joinTask = (taskId) => socket?.emit('join:task', taskId);
export const emitTyping = (taskId, typing) => socket?.emit(typing ? 'typing:start' : 'typing:stop', { taskId });
