import axios from 'axios';
import { auth } from './firebase';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api',
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
});

// Attach Firebase ID token to every request
api.interceptors.request.use(async (config) => {
  const user = auth.currentUser;
  if (user) {
    const token = await user.getIdToken();
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (err) => Promise.reject(err));

// Handle 401 globally
api.interceptors.response.use(
  (res) => res,
  async (err) => {
    if (err.response?.status === 401) {
      try {
        const user = auth.currentUser;
        if (user) {
          const token = await user.getIdToken(true); // force refresh
          err.config.headers.Authorization = `Bearer ${token}`;
          return api.request(err.config);
        }
      } catch {
        auth.signOut();
        window.location.href = '/login';
      }
    }
    return Promise.reject(err);
  }
);

// Convenience wrappers
export const apiGet = (url, params) => api.get(url, { params }).then(r => r.data);
export const apiPost = (url, data, config) => api.post(url, data, config).then(r => r.data);
export const apiPut = (url, data) => api.put(url, data).then(r => r.data);
export const apiPatch = (url, data) => api.patch(url, data).then(r => r.data);
export const apiDelete = (url) => api.delete(url).then(r => r.data);

export default api;
