import { useDashboard } from '../../hooks';
import { useAuth } from '../../context/AuthContext';
import { StatusBadge, PriorityBadge, Avatar, Skeleton, EmptyState } from '../../components/common';
import { formatDate, formatDue, isOverdue, cn } from '../../utils';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';

const STATUS_COLORS = { todo: '#64748b', in_progress: '#2563eb', in_review: '#7c3aed', done: '#16a34a', cancelled: '#dc2626' };
const PRIORITY_COLORS = { critical: '#dc2626', high: '#ea580c', medium: '#ca8a04', low: '#16a34a' };

export default function DashboardPage() {
  const { data, loading } = useDashboard();
  const { user, isAdmin } = useAuth();

  if (loading) return <DashboardSkeleton />;
  if (!data) return null;

  const { stats, tasksByUser, recentActivity, upcomingTasks, projectsProgress } = data;

  const pieData = Object.entries(stats).filter(([k]) =>
    ['doneTasks', 'inProgressTasks', 'todoTasks', 'overdueTasks'].includes(k)
  ).map(([k, v]) => ({
    name: { doneTasks: 'Done', inProgressTasks: 'In Progress', todoTasks: 'To Do', overdueTasks: 'Overdue' }[k],
    value: v,
    color: { doneTasks: '#16a34a', inProgressTasks: '#2563eb', todoTasks: '#64748b', overdueTasks: '#dc2626' }[k],
  })).filter(d => d.value > 0);

  const barData = tasksByUser.map(u => ({
    name: u.assignee?.name?.split(' ')[0] || 'Unknown',
    total: parseInt(u.dataValues?.total || 0),
    done: parseInt(u.dataValues?.done || 0),
  }));

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Good {getTimeOfDay()}, {user?.name?.split(' ')[0]} 👋</h1>
          <p className="text-sm text-slate-500 mt-0.5">Here's what's happening across your projects</p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Tasks" value={stats.totalTasks} icon="📋" trend={null} color="blue" />
        <StatCard label="Completed" value={stats.doneTasks} icon="✅" sub={`${stats.completionRate}% completion`} color="green" />
        <StatCard label="In Progress" value={stats.inProgressTasks} icon="⚡" color="blue" />
        <StatCard label="Overdue" value={stats.overdueTasks} icon="🔴" color="red" urgent={stats.overdueTasks > 0} />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Bar chart - tasks per user */}
        <div className="lg:col-span-2 card p-5">
          <h3 className="text-sm font-semibold text-slate-800 mb-4">Tasks per Team Member</h3>
          {barData.length === 0
            ? <EmptyState icon="📊" title="No task data yet" />
            : <ResponsiveContainer width="100%" height={200}>
                <BarChart data={barData} barGap={4}>
                  <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} width={24} />
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #e2e8f0', boxShadow: '0 4px 12px rgba(0,0,0,.08)' }} />
                  <Bar dataKey="total" name="Total" fill="#bfdbfe" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="done" name="Done" fill="#2563eb" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
          }
        </div>

        {/* Pie chart - status distribution */}
        <div className="card p-5">
          <h3 className="text-sm font-semibold text-slate-800 mb-4">Status Breakdown</h3>
          {pieData.length === 0
            ? <EmptyState icon="🥧" title="No data yet" />
            : <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={2}>
                    {pieData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                  </Pie>
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                  <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
          }
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Project Progress */}
        <div className="card p-5">
          <h3 className="text-sm font-semibold text-slate-800 mb-4">Project Progress</h3>
          {projectsProgress.length === 0
            ? <EmptyState icon="📁" title="No projects yet" />
            : <div className="space-y-3">
                {projectsProgress.map(p => (
                  <div key={p.id}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-medium text-slate-700 flex items-center gap-1">
                        <span>{p.emoji}</span> {p.name}
                      </span>
                      <span className="text-xs font-semibold text-slate-500">{p.progress}%</span>
                    </div>
                    <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-500" style={{ width: `${p.progress}%`, background: p.color }} />
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5">{p.doneCount}/{p.taskCount} tasks</div>
                  </div>
                ))}
              </div>
          }
        </div>

        {/* Upcoming Tasks */}
        <div className="card p-5">
          <h3 className="text-sm font-semibold text-slate-800 mb-4">Due This Week</h3>
          {upcomingTasks.length === 0
            ? <EmptyState icon="📅" title="Nothing due this week" subtitle="You're all clear!" />
            : <div className="space-y-2">
                {upcomingTasks.map(t => (
                  <div key={t.id} className={cn('p-2.5 rounded-lg border', isOverdue(t.due_date, t.status) ? 'border-red-200 bg-red-50' : 'border-slate-100 bg-slate-50')}>
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-xs font-medium text-slate-800 line-clamp-1">{t.title}</span>
                      <PriorityBadge priority={t.priority} iconOnly />
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[10px]">{t.project?.emoji}</span>
                      <span className="text-[10px] text-slate-400">{t.project?.name}</span>
                      <span className={cn('text-[10px] ml-auto', isOverdue(t.due_date, t.status) ? 'text-red-500 font-medium' : 'text-slate-400')}>
                        {formatDue(t.due_date)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
          }
        </div>

        {/* Recent Activity */}
        <div className="card p-5">
          <h3 className="text-sm font-semibold text-slate-800 mb-4">Recent Activity</h3>
          {recentActivity.length === 0
            ? <EmptyState icon="📜" title="No activity yet" />
            : <div className="space-y-3">
                {recentActivity.slice(0, 8).map(a => (
                  <div key={a.id} className="flex items-start gap-2.5">
                    <Avatar user={a.actor} size="xs" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-slate-600 leading-snug">
                        <span className="font-medium text-slate-800">{a.actor?.name?.split(' ')[0]}</span>
                        {' '}{a.action}
                        {a.meta?.title && <span className="font-medium text-slate-700"> "{a.meta.title}"</span>}
                      </p>
                      <span className="text-[10px] text-slate-400">{formatRelativeShort(a.created_at)}</span>
                    </div>
                  </div>
                ))}
              </div>
          }
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon, sub, color, urgent }) {
  const colors = { blue: 'text-blue-600 bg-blue-50', green: 'text-green-600 bg-green-50', red: 'text-red-600 bg-red-50' };
  return (
    <div className={cn('card p-4', urgent && 'border-red-200')}>
      <div className="flex items-center justify-between mb-3">
        <span className={cn('w-8 h-8 rounded-lg flex items-center justify-center text-lg', colors[color] || colors.blue)}>{icon}</span>
        {urgent && <span className="badge badge-red text-[10px]">Needs attention</span>}
      </div>
      <div className="text-2xl font-bold text-slate-900 font-mono">{value}</div>
      <div className="text-xs text-slate-500 mt-0.5">{label}</div>
      {sub && <div className="text-[10px] text-slate-400 mt-1">{sub}</div>}
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-64 skeleton" />
      <div className="grid grid-cols-4 gap-4">{[...Array(4)].map((_, i) => <div key={i} className="h-24 skeleton rounded-lg" />)}</div>
      <div className="grid grid-cols-3 gap-4">{[...Array(3)].map((_, i) => <div key={i} className="h-56 skeleton rounded-lg" />)}</div>
    </div>
  );
}

const getTimeOfDay = () => {
  const h = new Date().getHours();
  if (h < 12) return 'morning';
  if (h < 17) return 'afternoon';
  return 'evening';
};

const formatRelativeShort = (date) => {
  if (!date) return '';
  const diff = Date.now() - new Date(date).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
};
