import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { useTasks, useProjects } from '../../hooks';
import { useAuth } from '../../context/AuthContext';
import { StatusBadge, PriorityBadge, Avatar, Modal, Spinner, EmptyState } from '../../components/common';
import { apiGet, apiPost, apiPut, apiDelete } from '../../services/api';
import { formatDue, isOverdue, cn } from '../../utils';
import toast from 'react-hot-toast';

const COLUMNS = [
  { id: 'todo', label: 'To Do', color: '#64748b', bg: 'bg-slate-50' },
  { id: 'in_progress', label: 'In Progress', color: '#2563eb', bg: 'bg-blue-50/40' },
  { id: 'in_review', label: 'In Review', color: '#7c3aed', bg: 'bg-purple-50/40' },
  { id: 'done', label: 'Done', color: '#16a34a', bg: 'bg-green-50/40' },
];

export default function BoardPage() {
  const [searchParams] = useSearchParams();
  const projectFilter = searchParams.get('project');
  const { isAdmin, user } = useAuth();
  const { tasks, setTasks, loading, updateStatus, reorder } = useTasks({ projectId: projectFilter || undefined });
  const { projects } = useProjects();

  const [selectedProject, setSelectedProject] = useState(projectFilter || '');
  const [priorityFilter, setPriorityFilter] = useState('');
  const [assigneeFilter, setAssigneeFilter] = useState('');
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [editTask, setEditTask] = useState(null);
  const [selectedTask, setSelectedTask] = useState(null);

  const filtered = tasks.filter(t => {
    if (selectedProject && t.project_id !== selectedProject) return false;
    if (priorityFilter && t.priority !== priorityFilter) return false;
    if (assigneeFilter && t.assignee_id !== assigneeFilter) return false;
    return true;
  });

  const byColumn = (colId) => filtered.filter(t => t.status === colId).sort((a, b) => a.position - b.position);

  const onDragEnd = async (result) => {
    const { source, destination, draggableId } = result;
    if (!destination) return;
    if (source.droppableId === destination.droppableId && source.index === destination.index) return;

    const newStatus = destination.droppableId;
    const taskId = draggableId;

    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: newStatus } : t));

    try {
      await apiPut(`/tasks/${taskId}`, { status: newStatus, position: destination.index });
      toast.success(`Moved to ${COLUMNS.find(c => c.id === newStatus)?.label}`);
    } catch {
      setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: source.droppableId } : t));
      toast.error('Failed to update task');
    }
  };

  const handleOpenTask = async (task) => {
    try {
      const { task: full } = await apiGet(`/tasks/${task.id}`);
      setSelectedTask(full);
    } catch { setSelectedTask(task); }
  };

  const allAssignees = [...new Map(tasks.filter(t => t.assignee).map(t => [t.assignee_id, t.assignee])).values()];

  return (
    <div className="h-full flex flex-col animate-fade-in">
      {/* Toolbar */}
      <div className="flex items-center gap-3 mb-4 flex-wrap">
        <select className="input py-1.5 text-xs w-44" value={selectedProject} onChange={e => setSelectedProject(e.target.value)}>
          <option value="">All Projects</option>
          {projects.map(p => <option key={p.id} value={p.id}>{p.emoji} {p.name}</option>)}
        </select>

        <select className="input py-1.5 text-xs w-36" value={priorityFilter} onChange={e => setPriorityFilter(e.target.value)}>
          <option value="">All Priorities</option>
          {['critical', 'high', 'medium', 'low'].map(p => <option key={p} value={p} className="capitalize">{p}</option>)}
        </select>

        <select className="input py-1.5 text-xs w-40" value={assigneeFilter} onChange={e => setAssigneeFilter(e.target.value)}>
          <option value="">All Assignees</option>
          {allAssignees.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
        </select>

        <div className="text-xs text-slate-400 ml-1">{filtered.length} tasks</div>

        {isAdmin && (
          <button onClick={() => { setEditTask(null); setShowTaskModal(true); }} className="btn btn-primary ml-auto">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
            Add Task
          </button>
        )}
      </div>

      {/* Kanban Board */}
      {loading ? (
        <div className="flex gap-4 flex-1">
          {COLUMNS.map(c => <div key={c.id} className="flex-1 skeleton rounded-lg" />)}
        </div>
      ) : (
        <DragDropContext onDragEnd={onDragEnd}>
          <div className="flex gap-3 flex-1 overflow-x-auto pb-4">
            {COLUMNS.map(col => {
              const colTasks = byColumn(col.id);
              return (
                <div key={col.id} className="flex-1 min-w-[260px] max-w-xs flex flex-col kanban-col">
                  {/* Column header */}
                  <div className="flex items-center gap-2 px-3 py-2.5 border-b border-slate-200">
                    <div className="w-2.5 h-2.5 rounded-full" style={{ background: col.color }} />
                    <span className="text-xs font-semibold text-slate-700">{col.label}</span>
                    <span className="ml-auto bg-white border border-slate-200 text-slate-500 text-[10px] font-semibold px-1.5 py-0.5 rounded-full">{colTasks.length}</span>
                  </div>

                  {/* Droppable area */}
                  <Droppable droppableId={col.id}>
                    {(provided, snapshot) => (
                      <div ref={provided.innerRef} {...provided.droppableProps}
                        className={cn('flex-1 p-2 space-y-2 overflow-y-auto min-h-[100px] transition-colors', snapshot.isDraggingOver && 'bg-blue-50/60')}>
                        {colTasks.length === 0 && !snapshot.isDraggingOver && (
                          <div className="flex flex-col items-center justify-center py-8 text-center">
                            <div className="text-xl mb-1">📭</div>
                            <div className="text-xs text-slate-400">No tasks here</div>
                          </div>
                        )}
                        {colTasks.map((task, index) => (
                          <Draggable key={task.id} draggableId={task.id} index={index} isDragDisabled={!isAdmin && task.assignee_id !== user?.id}>
                            {(prov, snap) => (
                              <div ref={prov.innerRef} {...prov.draggableProps} {...prov.dragHandleProps}
                                className={cn('task-card-drag', snap.isDragging && 'shadow-lg rotate-1 border-blue-300')}
                                onClick={() => handleOpenTask(task)}>
                                <TaskCard task={task} />
                              </div>
                            )}
                          </Draggable>
                        ))}
                        {provided.placeholder}
                      </div>
                    )}
                  </Droppable>

                  {/* Add task button for admins */}
                  {isAdmin && (
                    <button onClick={() => { setEditTask({ status: col.id }); setShowTaskModal(true); }}
                      className="flex items-center gap-1.5 px-3 py-2 text-xs text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors border-t border-slate-100">
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                      Add task
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </DragDropContext>
      )}

      {showTaskModal && <TaskFormModal initialData={editTask} projects={projects} onClose={() => setShowTaskModal(false)} onSaved={(task) => { setShowTaskModal(false); if (!tasks.find(t => t.id === task.id)) setTasks(prev => [task, ...prev]); else setTasks(prev => prev.map(t => t.id === task.id ? task : t)); }} />}
      {selectedTask && <TaskDetailModal task={selectedTask} isAdmin={isAdmin} currentUser={user} onClose={() => setSelectedTask(null)} onUpdate={(updated) => { setTasks(prev => prev.map(t => t.id === updated.id ? updated : t)); setSelectedTask(updated); }} onDelete={(id) => { setTasks(prev => prev.filter(t => t.id !== id)); setSelectedTask(null); }} />}
    </div>
  );
}

function TaskCard({ task }) {
  const overdue = isOverdue(task.due_date, task.status);
  return (
    <div>
      <div className="flex items-start justify-between gap-2 mb-2">
        <p className="text-xs font-medium text-slate-800 leading-snug line-clamp-2">{task.title}</p>
        <PriorityBadge priority={task.priority} iconOnly />
      </div>
      {task.description && <p className="text-[10px] text-slate-400 line-clamp-1 mb-2">{task.description}</p>}
      <div className="flex items-center justify-between mt-2">
        <div className="flex items-center gap-1">
          <span className="text-[10px] text-slate-400">{task.project?.emoji} {task.project?.name}</span>
        </div>
        <div className="flex items-center gap-1.5">
          {task.due_date && (
            <span className={cn('text-[10px]', overdue ? 'text-red-500 font-medium' : 'text-slate-400')}>
              {overdue ? '⚠ ' : '📅 '}{formatDue(task.due_date)}
            </span>
          )}
          {task.assignee && <Avatar user={task.assignee} size="xs" />}
        </div>
      </div>
      {task.checklist?.length > 0 && (
        <div className="mt-2 pt-2 border-t border-slate-100">
          <div className="flex items-center gap-1.5">
            <div className="flex-1 h-1 bg-slate-100 rounded-full overflow-hidden">
              <div className="h-full bg-green-500 rounded-full" style={{ width: `${task.checklist.filter(i => i.done).length / task.checklist.length * 100}%` }} />
            </div>
            <span className="text-[10px] text-slate-400">{task.checklist.filter(i => i.done).length}/{task.checklist.length}</span>
          </div>
        </div>
      )}
    </div>
  );
}

function TaskFormModal({ initialData, projects, onClose, onSaved }) {
  const { user } = useAuth();
  const [form, setForm] = useState({ title: '', description: '', status: 'todo', priority: 'medium', project_id: projects[0]?.id || '', assignee_id: '', due_date: '', estimated_hours: '', labels: [], ...initialData });
  const [loading, setLoading] = useState(false);
  const [members, setMembers] = useState([]);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (form.project_id) {
      apiGet(`/projects/${form.project_id}`).then(r => setMembers(r.project.members || [])).catch(() => {});
    }
  }, [form.project_id]);

  const set = k => e => setForm(f => ({ ...f, [k]: e.target?.value ?? e }));

  const validate = () => {
    const e = {};
    if (!form.title.trim()) e.title = 'Title required';
    if (!form.project_id) e.project_id = 'Select a project';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      let task;
      if (form.id) {
        const res = await apiPut(`/tasks/${form.id}`, form);
        task = res.task;
      } else {
        const res = await apiPost('/tasks', form);
        task = res.task;
      }
      onSaved(task);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to save task');
    } finally { setLoading(false); }
  };

  return (
    <Modal open title={form.id ? 'Edit Task' : 'New Task'} onClose={onClose} size="lg"
      footer={<>
        <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary" onClick={submit} disabled={loading}>{loading ? <Spinner size="sm" /> : form.id ? 'Save Changes' : 'Create Task'}</button>
      </>}>
      <div className="grid grid-cols-3 gap-4">
        <div className="col-span-2 space-y-3">
          <div>
            <label className="label">Title *</label>
            <input className={cn('input', errors.title && 'input-error')} placeholder="What needs to be done?" value={form.title} onChange={set('title')} />
            {errors.title && <p className="form-error">{errors.title}</p>}
          </div>
          <div>
            <label className="label">Description</label>
            <textarea className="input resize-none" rows={4} placeholder="Add more context, acceptance criteria..." value={form.description} onChange={set('description')} />
          </div>
        </div>
        <div className="space-y-3">
          <div>
            <label className="label">Project *</label>
            <select className="input" value={form.project_id} onChange={set('project_id')}>
              {projects.map(p => <option key={p.id} value={p.id}>{p.emoji} {p.name}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Status</label>
            <select className="input" value={form.status} onChange={set('status')}>
              {COLUMNS.map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Priority</label>
            <select className="input" value={form.priority} onChange={set('priority')}>
              {['critical', 'high', 'medium', 'low'].map(p => <option key={p} value={p} className="capitalize">{p}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Assignee</label>
            <select className="input" value={form.assignee_id} onChange={set('assignee_id')}>
              <option value="">Unassigned</option>
              {members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Due Date</label>
            <input type="date" className="input" value={form.due_date} onChange={set('due_date')} />
          </div>
          <div>
            <label className="label">Est. Hours</label>
            <input type="number" className="input" placeholder="e.g. 4" value={form.estimated_hours} onChange={set('estimated_hours')} min={0} />
          </div>
        </div>
      </div>
    </Modal>
  );
}

function TaskDetailModal({ task, isAdmin, currentUser, onClose, onUpdate, onDelete }) {
  const [comments, setComments] = useState(task.comments || []);
  const [commentText, setCommentText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [commentFile, setCommentFile] = useState(null);

  const submitComment = async () => {
    if (!commentText.trim()) return;
    setSubmitting(true);
    try {
      const fd = new FormData();
      fd.append('content', commentText);
      if (commentFile) fd.append('file', commentFile);
      const res = await apiPost(`/tasks/${task.id}/comments`, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      setComments(prev => [...prev, res.comment]);
      setCommentText('');
      setCommentFile(null);
    } catch { toast.error('Failed to post comment'); }
    finally { setSubmitting(false); }
  };

  const deleteComment = async (commentId) => {
    await apiDelete(`/tasks/${task.id}/comments/${commentId}`);
    setComments(prev => prev.filter(c => c.id !== commentId));
  };

  const handleDelete = async () => {
    if (!confirm('Delete this task?')) return;
    await apiDelete(`/tasks/${task.id}`);
    onDelete(task.id);
    toast.success('Task deleted');
  };

  return (
    <Modal open title="" onClose={onClose} size="xl">
      <div className="grid grid-cols-3 gap-6 -mt-2">
        {/* Main */}
        <div className="col-span-2">
          <div className="flex items-start gap-2 mb-1">
            <PriorityBadge priority={task.priority} />
            <StatusBadge status={task.status} />
          </div>
          <h2 className="text-lg font-semibold text-slate-900 mt-2 mb-3">{task.title}</h2>
          {task.description && <p className="text-sm text-slate-600 leading-relaxed mb-4">{task.description}</p>}

          {/* Attachments */}
          {task.attachments?.length > 0 && (
            <div className="mb-4">
              <div className="text-xs font-semibold text-slate-500 mb-2">Attachments ({task.attachments.length})</div>
              <div className="flex flex-wrap gap-2">
                {task.attachments.map(a => (
                  <a key={a.id} href={a.path} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded text-xs text-slate-600 hover:border-blue-300 hover:bg-blue-50 transition-colors">
                    📎 {a.filename}
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* Comments */}
          <div>
            <div className="text-xs font-semibold text-slate-500 mb-3">Comments ({comments.length})</div>
            <div className="space-y-3 mb-4">
              {comments.map(c => (
                <div key={c.id} className="flex gap-2.5">
                  <Avatar user={c.author} size="sm" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-medium text-slate-800">{c.author?.name}</span>
                      <span className="text-[10px] text-slate-400">{formatRelativeShort(c.created_at)}</span>
                      {c.is_edited && <span className="text-[10px] text-slate-300">(edited)</span>}
                    </div>
                    <div className="text-xs text-slate-600 bg-slate-50 rounded-lg p-2.5 border border-slate-100">{c.content}</div>
                    {(c.user_id === currentUser?.id || isAdmin) && (
                      <button onClick={() => deleteComment(c.id)} className="text-[10px] text-slate-400 hover:text-red-500 mt-1">Delete</button>
                    )}
                  </div>
                </div>
              ))}
            </div>
            <div className="flex gap-2 items-start">
              <Avatar user={currentUser} size="sm" />
              <div className="flex-1">
                <textarea className="input text-xs resize-none" rows={2} placeholder="Add a comment..." value={commentText} onChange={e => setCommentText(e.target.value)} />
                <div className="flex items-center gap-2 mt-1.5">
                  <label className="cursor-pointer text-xs text-slate-400 hover:text-blue-600">
                    📎 Attach
                    <input type="file" className="hidden" onChange={e => setCommentFile(e.target.files[0])} />
                  </label>
                  {commentFile && <span className="text-[10px] text-slate-500 truncate max-w-[100px]">{commentFile.name}</span>}
                  <button onClick={submitComment} disabled={submitting || !commentText.trim()} className="ml-auto btn btn-primary btn-sm">
                    {submitting ? <Spinner size="xs" /> : 'Post'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar metadata */}
        <div className="space-y-4 border-l border-slate-100 pl-6">
          <MetaRow label="Project" value={<span className="flex items-center gap-1">{task.project?.emoji} {task.project?.name}</span>} />
          <MetaRow label="Assignee" value={task.assignee ? <div className="flex items-center gap-1.5"><Avatar user={task.assignee} size="xs" /><span>{task.assignee.name}</span></div> : <span className="text-slate-400">Unassigned</span>} />
          <MetaRow label="Reporter" value={task.creator?.name || '—'} />
          <MetaRow label="Due Date" value={task.due_date ? <span className={cn(isOverdue(task.due_date, task.status) && 'text-red-500 font-medium')}>{formatDate(task.due_date)}</span> : '—'} />
          <MetaRow label="Est. Hours" value={task.estimated_hours ? `${task.estimated_hours}h` : '—'} />
          <MetaRow label="Created" value={formatDate(task.created_at)} />

          {isAdmin && (
            <button onClick={handleDelete} className="btn btn-danger btn-sm w-full justify-center mt-4">
              🗑 Delete Task
            </button>
          )}
        </div>
      </div>
    </Modal>
  );
}

function MetaRow({ label, value }) {
  return (
    <div>
      <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">{label}</div>
      <div className="text-xs text-slate-700">{value}</div>
    </div>
  );
}

const formatDate = (d) => d ? new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : null;
const formatRelativeShort = (date) => {
  if (!date) return '';
  const diff = Date.now() - new Date(date).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
};
