import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

export default function LandingPage() {
  const { firebaseUser } = useAuth();

  return (
    <div className="min-h-screen bg-white font-sans">
      {/* ── Navbar ── */}
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur border-b border-slate-100">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-sm">N</div>
            <span className="font-bold text-slate-900 text-lg">NexusFlow</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm text-slate-600">
            <a href="#features" className="hover:text-blue-600 transition-colors">Features</a>
            <a href="#roles" className="hover:text-blue-600 transition-colors">How it works</a>
            <a href="#pricing" className="hover:text-blue-600 transition-colors">Pricing</a>
          </div>
          <div className="flex items-center gap-3">
            {firebaseUser ? (
              <Link to="/dashboard" className="bg-blue-600 text-white text-sm font-medium px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                Go to Dashboard →
              </Link>
            ) : (
              <>
                <Link to="/login" className="text-sm text-slate-600 font-medium hover:text-slate-900 transition-colors">Sign in</Link>
                <Link to="/signup" className="bg-blue-600 text-white text-sm font-medium px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                  Get started free
                </Link>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* ── Hero ── */}
      <section className="relative overflow-hidden bg-gradient-to-b from-slate-50 to-white pt-20 pb-28 px-6">
        {/* Background grid */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#e2e8f033_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f033_1px,transparent_1px)] bg-[size:48px_48px]" />
        {/* Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-blue-100/60 rounded-full blur-3xl" />

        <div className="relative max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-blue-50 border border-blue-200 text-blue-700 text-xs font-semibold px-3 py-1.5 rounded-full mb-6">
            <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse" />
            Built for Freelancers + Client Collaboration
          </div>

          <h1 className="text-5xl md:text-6xl font-extrabold text-slate-900 leading-[1.1] tracking-tight mb-6">
            Manage projects,<br />
            <span className="bg-gradient-to-r from-blue-600 to-violet-600 bg-clip-text text-transparent">
              delight your clients.
            </span>
          </h1>

          <p className="text-xl text-slate-500 max-w-2xl mx-auto mb-10 leading-relaxed">
            NexusFlow gives freelancers and teams a Jira-grade task manager with real-time updates, role-based access, and a client portal — all in one place.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link to="/signup" className="w-full sm:w-auto bg-blue-600 text-white font-semibold px-8 py-3.5 rounded-xl hover:bg-blue-700 transition-all hover:shadow-lg hover:-translate-y-0.5 text-base">
              Start for free →
            </Link>
            <Link to="/login" className="w-full sm:w-auto bg-white text-slate-700 font-semibold px-8 py-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 transition-all text-base">
              Sign in
            </Link>
          </div>

          <p className="text-xs text-slate-400 mt-4">No credit card required · Free forever for small teams</p>
        </div>

        {/* Hero screenshot mockup */}
        <div className="relative max-w-5xl mx-auto mt-16">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            {/* Fake browser bar */}
            <div className="flex items-center gap-2 px-4 py-3 bg-slate-50 border-b border-slate-200">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-400" />
                <div className="w-3 h-3 rounded-full bg-yellow-400" />
                <div className="w-3 h-3 rounded-full bg-green-400" />
              </div>
              <div className="flex-1 bg-white border border-slate-200 rounded px-3 py-1 text-xs text-slate-400 max-w-xs mx-auto text-center">
                nexusflow.vercel.app/dashboard
              </div>
            </div>
            {/* Dashboard mockup */}
            <div className="flex h-80 bg-slate-50">
              {/* Sidebar */}
              <div className="w-48 bg-white border-r border-slate-200 p-3 flex flex-col gap-1 flex-shrink-0">
                <div className="flex items-center gap-2 px-2 py-2 mb-2">
                  <div className="w-6 h-6 bg-blue-600 rounded text-white text-[10px] font-bold flex items-center justify-center">N</div>
                  <span className="text-xs font-semibold">NexusFlow</span>
                </div>
                {['📊 Dashboard','📁 Projects','🗂️ Board','👥 Team'].map((item, i) => (
                  <div key={i} className={`flex items-center gap-2 px-2 py-1.5 rounded text-xs ${i === 0 ? 'bg-blue-50 text-blue-700 font-medium' : 'text-slate-500'}`}>
                    {item}
                  </div>
                ))}
              </div>
              {/* Content */}
              <div className="flex-1 p-4 overflow-hidden">
                <div className="text-sm font-semibold text-slate-800 mb-3">Good morning, Shivam 👋</div>
                {/* Stat cards */}
                <div className="grid grid-cols-4 gap-2 mb-3">
                  {[['📋','24','Total Tasks'],['✅','16','Completed'],['⚡','6','In Progress'],['🔴','2','Overdue']].map(([icon,val,label],i)=>(
                    <div key={i} className="bg-white border border-slate-200 rounded-lg p-2.5">
                      <div className="text-base">{icon}</div>
                      <div className="text-lg font-bold text-slate-900 font-mono">{val}</div>
                      <div className="text-[10px] text-slate-400">{label}</div>
                    </div>
                  ))}
                </div>
                {/* Chart placeholder */}
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-white border border-slate-200 rounded-lg p-3">
                    <div className="text-xs font-semibold text-slate-600 mb-2">Tasks per Member</div>
                    <div className="flex items-end gap-1.5 h-12">
                      {[70,45,90,55,80,35].map((h,i)=>(
                        <div key={i} className="flex-1 rounded-t" style={{height:`${h}%`,background:['#bfdbfe','#93c5fd','#3b82f6','#2563eb','#1d4ed8','#60a5fa'][i]}} />
                      ))}
                    </div>
                  </div>
                  <div className="bg-white border border-slate-200 rounded-lg p-3">
                    <div className="text-xs font-semibold text-slate-600 mb-2">Status Breakdown</div>
                    <div className="flex items-center gap-2">
                      <svg width="48" height="48" viewBox="0 0 48 48">
                        <circle cx="24" cy="24" r="16" fill="none" stroke="#e2e8f0" strokeWidth="8"/>
                        <circle cx="24" cy="24" r="16" fill="none" stroke="#2563eb" strokeWidth="8" strokeDasharray="63 38" strokeDashoffset="25" strokeLinecap="round"/>
                      </svg>
                      <div className="text-[10px] space-y-0.5">
                        {[['#16a34a','Done 67%'],['#2563eb','Active 25%'],['#dc2626','Late 8%']].map(([c,l],i)=>(
                          <div key={i} className="flex items-center gap-1"><div className="w-1.5 h-1.5 rounded-full" style={{background:c}}/><span className="text-slate-500">{l}</span></div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* Floating badges */}
          <div className="absolute -left-4 top-1/3 bg-white border border-slate-200 rounded-xl shadow-lg px-3 py-2 flex items-center gap-2 text-xs font-medium text-slate-700">
            <span className="w-2 h-2 bg-green-500 rounded-full" /> Real-time sync
          </div>
          <div className="absolute -right-4 top-1/4 bg-white border border-slate-200 rounded-xl shadow-lg px-3 py-2 flex items-center gap-2 text-xs font-medium text-slate-700">
            🔔 Task assigned to you
          </div>
        </div>
      </section>

      {/* ── Logos ── */}
      <section className="border-y border-slate-100 py-8 px-6 bg-slate-50">
        <p className="text-center text-xs text-slate-400 font-medium uppercase tracking-wider mb-6">Built with industry-standard tools</p>
        <div className="flex flex-wrap items-center justify-center gap-8 opacity-60">
          {['React', 'Node.js', 'PostgreSQL', 'Firebase', 'Socket.io', 'Railway', 'Vercel'].map(t => (
            <span key={t} className="text-sm font-semibold text-slate-500">{t}</span>
          ))}
        </div>
      </section>

      {/* ── Features ── */}
      <section id="features" className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <div className="text-xs font-semibold text-blue-600 uppercase tracking-wider mb-3">Features</div>
            <h2 className="text-4xl font-extrabold text-slate-900 mb-4">Everything your team needs</h2>
            <p className="text-slate-500 max-w-xl mx-auto">From drag-and-drop Kanban boards to real-time notifications — NexusFlow has every tool you need to ship faster.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon:'🗂️', title:'Kanban Board', desc:'Drag and drop tasks across Todo, In Progress, In Review, and Done columns. Real-time updates for your whole team.', color:'bg-blue-50 text-blue-600' },
              { icon:'📊', title:'Analytics Dashboard', desc:'Bar charts, pie charts, overdue tracking, team performance metrics — all at a glance.', color:'bg-violet-50 text-violet-600' },
              { icon:'👥', title:'Client Portal', desc:'Share a read-only project view with your clients. They see progress without touching anything.', color:'bg-green-50 text-green-600' },
              { icon:'🔔', title:'Real-time Notifications', desc:'Get instant in-app and email alerts when tasks are assigned, updated, or overdue.', color:'bg-amber-50 text-amber-600' },
              { icon:'🔐', title:'Role-Based Access', desc:'Admin, Member, and Client roles. Each sees exactly what they need — nothing more.', color:'bg-red-50 text-red-600' },
              { icon:'📎', title:'File Attachments', desc:'Attach designs, docs, and screenshots directly to tasks. Keep all context in one place.', color:'bg-teal-50 text-teal-600' },
            ].map((f, i) => (
              <div key={i} className="bg-white border border-slate-200 rounded-2xl p-6 hover:shadow-md hover:border-slate-300 transition-all group">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl mb-4 ${f.color}`}>{f.icon}</div>
                <h3 className="text-base font-semibold text-slate-900 mb-2">{f.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── How it works / Roles ── */}
      <section id="roles" className="py-24 px-6 bg-slate-50">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <div className="text-xs font-semibold text-blue-600 uppercase tracking-wider mb-3">Roles</div>
            <h2 className="text-4xl font-extrabold text-slate-900 mb-4">Built for every stakeholder</h2>
            <p className="text-slate-500 max-w-xl mx-auto">Different users, different views — all working from the same source of truth.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { role:'Admin', icon:'👑', color:'border-blue-300 bg-blue-50', badge:'bg-blue-100 text-blue-700', perms:['Create & manage projects','Add/remove team members','Assign tasks to anyone','Full dashboard visibility','Delete tasks & projects','Manage client access'] },
              { role:'Member', icon:'💼', color:'border-green-300 bg-green-50', badge:'bg-green-100 text-green-700', perms:['View assigned projects','Create tasks in projects','Update own task status','Comment on tasks','Upload file attachments','Real-time notifications'] },
              { role:'Client', icon:'👁️', color:'border-violet-300 bg-violet-50', badge:'bg-violet-100 text-violet-700', perms:['View project progress','See task statuses','Track project milestones','View team members','Read comments','No editing access'] },
            ].map((r, i) => (
              <div key={i} className={`border-2 ${r.color} rounded-2xl p-6`}>
                <div className="flex items-center gap-3 mb-5">
                  <span className="text-3xl">{r.icon}</span>
                  <span className={`${r.badge} font-semibold text-sm px-3 py-1 rounded-full`}>{r.role}</span>
                </div>
                <ul className="space-y-2">
                  {r.perms.map((p, j) => (
                    <li key={j} className="flex items-center gap-2 text-sm text-slate-600">
                      <svg className="w-4 h-4 text-green-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7"/></svg>
                      {p}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Pricing ── */}
      <section id="pricing" className="py-24 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <div className="text-xs font-semibold text-blue-600 uppercase tracking-wider mb-3">Pricing</div>
            <h2 className="text-4xl font-extrabold text-slate-900 mb-4">Simple, honest pricing</h2>
            <p className="text-slate-500">Start free. Upgrade when you grow.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl mx-auto">
            <div className="border border-slate-200 rounded-2xl p-8 bg-white">
              <div className="text-sm font-semibold text-slate-500 mb-2">Starter</div>
              <div className="text-4xl font-extrabold text-slate-900 mb-1">Free</div>
              <div className="text-sm text-slate-400 mb-6">Forever</div>
              <ul className="space-y-2.5 text-sm text-slate-600 mb-8">
                {['Up to 3 projects','5 team members','Kanban board','Basic dashboard','Email notifications'].map(f=>(
                  <li key={f} className="flex items-center gap-2"><svg className="w-4 h-4 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7"/></svg>{f}</li>
                ))}
              </ul>
              <Link to="/signup" className="block text-center bg-slate-100 text-slate-800 font-semibold py-2.5 rounded-xl hover:bg-slate-200 transition-colors">Get started</Link>
            </div>
            <div className="border-2 border-blue-500 rounded-2xl p-8 bg-blue-600 text-white relative overflow-hidden">
              <div className="absolute top-4 right-4 text-[10px] font-bold bg-white text-blue-600 px-2 py-0.5 rounded-full">POPULAR</div>
              <div className="text-sm font-semibold text-blue-200 mb-2">Pro</div>
              <div className="text-4xl font-extrabold mb-1">₹499<span className="text-xl font-normal text-blue-200">/mo</span></div>
              <div className="text-sm text-blue-200 mb-6">Per workspace</div>
              <ul className="space-y-2.5 text-sm text-blue-100 mb-8">
                {['Unlimited projects','Unlimited members','Client portal access','File uploads (10GB)','Real-time Socket.io','Priority support'].map(f=>(
                  <li key={f} className="flex items-center gap-2"><svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7"/></svg>{f}</li>
                ))}
              </ul>
              <Link to="/signup" className="block text-center bg-white text-blue-600 font-semibold py-2.5 rounded-xl hover:bg-blue-50 transition-colors">Start free trial</Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-24 px-6 bg-gradient-to-br from-blue-600 to-violet-700 text-white">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-4xl font-extrabold mb-4">Ready to ship faster?</h2>
          <p className="text-blue-100 text-lg mb-8">Join teams who use NexusFlow to manage projects, collaborate with clients, and deliver on time.</p>
          <Link to="/signup" className="inline-flex items-center gap-2 bg-white text-blue-700 font-bold px-8 py-3.5 rounded-xl hover:bg-blue-50 transition-all hover:shadow-lg hover:-translate-y-0.5 text-base">
            Create your free account →
          </Link>
          <p className="text-blue-200 text-xs mt-4">Takes 30 seconds. No credit card.</p>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer className="border-t border-slate-200 py-10 px-6 bg-white">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-blue-600 rounded flex items-center justify-center text-white font-bold text-xs">N</div>
            <span className="font-semibold text-slate-800">NexusFlow</span>
          </div>
          <div className="flex items-center gap-6 text-sm text-slate-400">
            <a href="#features" className="hover:text-slate-600">Features</a>
            <a href="#pricing" className="hover:text-slate-600">Pricing</a>
            <Link to="/login" className="hover:text-slate-600">Login</Link>
            <Link to="/signup" className="hover:text-slate-600">Sign up</Link>
          </div>
          <p className="text-xs text-slate-400">© 2025 NexusFlow. Built with ❤️</p>
        </div>
      </footer>
    </div>
  );
}
