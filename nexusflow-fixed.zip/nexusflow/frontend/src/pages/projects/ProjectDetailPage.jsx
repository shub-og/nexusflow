import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useProjects } from '../../hooks';
import { Avatar, StatusBadge, Modal, EmptyState, Spinner } from '../../components/common';
import { apiGet } from '../../services/api';
import { formatDate, formatRelativeShort, cn } from '../../utils';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import toast from 'react-hot-toast';

export default function ProjectDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isAdmin } = useAuth();
  const { addMember, removeMember, update } = useProjects();
  const [project, setProject] = useState(null);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('overview');
  const [showAddMember, setShowAddMember] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        const [projRes, analyticsRes] = await Promise.all([
          apiGet(`/projects/${id}`),
          apiGet(`/projects/${id}/analytics`),
        ]);
        setProject(projRes.project);
        setAnalytics(analyticsRes);
      } catch {
        toast.error('Failed to load project');
        navigate('/projects');
      } finally { setLoading(false); }
    };
    load();
  }, [id]);

  if (loading) return <div className="flex items-center justify-center h-64"><Spinner size="lg" /></div>;
  if (!project) return null;

  const userBarData = analytics?.byUser?.map(u => ({
    name: u.user?.name?.split(' ')[0] || '?',
    total: u.total, done: u.done,
  })) || [];

  const handleRemoveMember = async (userId) => {
    if (!confirm('Remove this member?')) return;
    await removeMember(id, userId);
    setProject(prev => ({ ...prev, members: prev.members.filter(m => m.id !== userId) }));
  };

  const handleAddMember = async (userId) => {
    await addMember(id, userId);
    const refreshed = await apiGet(`/projects/${id}`);
    setProject(refreshed.project);
    setShowAddMember(false);
  };

  const pct = analytics?.completionRate || 0;

  return (
    <div className="max-w-6xl mx-auto animate-fade-in">
      {/* Header */}
      <div className="flex items-start gap-4 mb-6">
        <button onClick={() => navigate('/projects')} className="mt-1 p-1.5 rounded hover:bg-slate-100 text-slate-400">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
        </button>
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-1">
            <span className="text-2xl">{project.emoji}</span>
            <h1 className="text-xl font-bold text-slate-900">{project.name}</h1>
            <span className="badge badge-green capitalize">{project.status}</span>
          </div>
          {project.description && <p className="text-sm text-slate-500">{project.description}</p>}
          <div className="flex items-center gap-4 mt-2 text-xs text-slate-400">
            {project.start_date && <span>📅 Start: {formatDate(project.start_date)}</span>}
            {project.due_date && <span>🏁 Due: {formatDate(project.due_date)}</span>}
            <span>👤 Owner: {project.owner?.name}</span>
          </div>
        </div>
        {isAdmin && (
          <button onClick={() => navigate(`/board?project=${id}`)} className="btn btn-primary">
            Open Board →
          </button>
        )}
      </div>

      {/* Stats bar */}
      <div className="grid grid-cols-5 gap-3 mb-6">
        {[
          { label: 'Total', value: analytics?.totalTasks || 0, color: 'text-slate-800' },
          { label: 'Done', value: analytics?.byStatus?.done || 0, color: 'text-green-600' },
          { label: 'In Progress', value: analytics?.byStatus?.in_progress || 0, color: 'text-blue-600' },
          { label: 'To Do', value: analytics?.byStatus?.todo || 0, color: 'text-slate-500' },
          { label: 'Overdue', value: analytics?.overdueTasks || 0, color: 'text-red-600' },
        ].map(s => (
          <div key={s.label} className="card p-3 text-center">
            <div className={cn('text-xl font-bold font-mono', s.color)}>{s.value}</div>
            <div className="text-[10px] text-slate-400">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Progress */}
      <div className="card p-4 mb-6">
        <div className="flex items-center justify-between text-xs mb-2">
          <span className="font-medium text-slate-700">Overall Progress</span>
          <span className="font-bold text-slate-900">{pct}%</span>
        </div>
        <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
          <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: project.color || '#2563eb' }} />
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-5 border-b border-slate-200">
        {['overview', 'members', 'analytics'].map(t => (
          <button key={t} onClick={() => setTab(t)} className={cn('px-4 py-2.5 text-sm font-medium border-b-2 transition-colors capitalize', tab === t ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700')}>
            {t}
          </button>
        ))}
      </div>

      {tab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Activity feed */}
          <div className="card p-5">
            <h3 className="text-sm font-semibold text-slate-800 mb-4">Recent Activity</h3>
            {project.activities?.length === 0
              ? <EmptyState icon="📜" title="No activity yet" />
              : <div className="space-y-3">
                  {(project.activities || []).map(a => (
                    <div key={a.id} className="flex items-start gap-2.5">
                      <Avatar user={a.actor} size="xs" />
                      <div className="flex-1">
                        <p className="text-xs text-slate-600">
                          <span className="font-medium text-slate-800">{a.actor?.name?.split(' ')[0]}</span> {a.action}
                          {a.meta?.title && <span className="font-medium"> "{a.meta.title}"</span>}
                          {a.meta?.status_change && <span className="text-slate-400"> · {a.meta.status_change.from} → {a.meta.status_change.to}</span>}
                        </p>
                        <span className="text-[10px] text-slate-400">{formatRelativeShort(a.created_at)}</span>
                      </div>
                    </div>
                  ))}
                </div>
            }
          </div>
          {/* Members quick view */}
          <div className="card p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-slate-800">Team ({project.members?.length})</h3>
              {isAdmin && <button onClick={() => setShowAddMember(true)} className="btn btn-secondary btn-sm">+ Add</button>}
            </div>
            <div className="space-y-2">
              {(project.members || []).map(m => (
                <div key={m.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-50">
                  <Avatar user={m} size="sm" />
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-slate-800 truncate">{m.name}</div>
                    <div className="text-[10px] text-slate-400 truncate">{m.email}</div>
                  </div>
                  <span className={cn('badge text-[10px]', m.ProjectMember?.role === 'admin' ? 'badge-blue' : m.role === 'client' ? 'badge-purple' : 'badge-gray')}>
                    {m.ProjectMember?.role || m.role}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {tab === 'members' && (
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold">Team Members ({project.members?.length})</h3>
            {isAdmin && <button onClick={() => setShowAddMember(true)} className="btn btn-primary btn-sm">+ Add Member</button>}
          </div>
          <div className="divide-y divide-slate-100">
            {(project.members || []).map(m => (
              <div key={m.id} className="flex items-center gap-4 py-3">
                <Avatar user={m} size="md" />
                <div className="flex-1">
                  <div className="text-sm font-medium text-slate-800">{m.name}</div>
                  <div className="text-xs text-slate-400">{m.email}</div>
                </div>
                <span className={cn('badge', m.ProjectMember?.role === 'admin' ? 'badge-blue' : m.role === 'client' ? 'badge-purple' : 'badge-gray')}>
                  {m.ProjectMember?.role}
                </span>
                <span className="text-[10px] text-slate-400">Joined {formatDate(m.ProjectMember?.joined_at)}</span>
                {isAdmin && m.ProjectMember?.role !== 'admin' && (
                  <button onClick={() => handleRemoveMember(m.id)} className="btn btn-ghost btn-sm text-red-500 hover:bg-red-50">Remove</button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'analytics' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="card p-5">
            <h3 className="text-sm font-semibold mb-4">Tasks per Member</h3>
            {userBarData.length === 0
              ? <EmptyState icon="📊" title="No data yet" />
              : <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={userBarData}>
                    <XAxis dataKey="name" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} width={24} />
                    <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                    <Bar dataKey="total" name="Total" fill="#bfdbfe" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="done" name="Done" fill="#2563eb" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
            }
          </div>
          <div className="card p-5">
            <h3 className="text-sm font-semibold mb-4">Priority Breakdown</h3>
            <div className="space-y-3">
              {Object.entries(analytics?.byPriority || {}).map(([p, count]) => (
                <div key={p}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="capitalize font-medium text-slate-700">{p}</span>
                    <span className="text-slate-500">{count}</span>
                  </div>
                  <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${analytics?.totalTasks ? count / analytics.totalTasks * 100 : 0}%`, background: { critical: '#dc2626', high: '#ea580c', medium: '#ca8a04', low: '#16a34a' }[p] }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {showAddMember && <AddMemberModal onClose={() => setShowAddMember(false)} onAdd={handleAddMember} existingIds={(project.members || []).map(m => m.id)} />}
    </div>
  );
}

function AddMemberModal({ onClose, onAdd, existingIds }) {
  const [search, setSearch] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const debouncedSearch = search;

  useEffect(() => {
    if (search.length < 2) { setResults([]); return; }
    const t = setTimeout(async () => {
      setLoading(true);
      try {
        const data = await apiGet('/users/search', { q: search });
        setResults(data.users.filter(u => !existingIds.includes(u.id)));
      } finally { setLoading(false); }
    }, 300);
    return () => clearTimeout(t);
  }, [search]);

  return (
    <Modal open title="Add Team Member" onClose={onClose} size="sm"
      footer={<button className="btn btn-secondary" onClick={onClose}>Cancel</button>}>
      <div className="space-y-3">
        <input className="input" placeholder="Search by name or email..." value={search} onChange={e => setSearch(e.target.value)} autoFocus />
        {loading && <div className="flex justify-center py-4"><Spinner /></div>}
        {results.map(u => (
          <div key={u.id} className="flex items-center gap-3 p-2.5 rounded-lg border border-slate-100 hover:border-blue-200 hover:bg-blue-50 cursor-pointer transition-colors" onClick={() => onAdd(u.id)}>
            <Avatar user={u} size="sm" />
            <div className="flex-1">
              <div className="text-sm font-medium">{u.name}</div>
              <div className="text-xs text-slate-400">{u.email}</div>
            </div>
            <span className={cn('badge text-[10px]', u.role === 'admin' ? 'badge-blue' : 'badge-gray')}>{u.role}</span>
          </div>
        ))}
        {search.length >= 2 && !loading && results.length === 0 && (
          <p className="text-sm text-center text-slate-400 py-4">No users found</p>
        )}
      </div>
    </Modal>
  );
}

const formatRelativeShort = (date) => {
  if (!date) return '';
  const diff = Date.now() - new Date(date).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
};
