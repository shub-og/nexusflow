import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useProjects } from '../../hooks';
import { useAuth } from '../../context/AuthContext';
import { Modal, Avatar, AvatarGroup, EmptyState, Spinner } from '../../components/common';
import { cn, formatDate } from '../../utils';
import { apiGet, apiPost, apiDelete } from '../../services/api';
import { useDebounce } from '../../hooks';
import toast from 'react-hot-toast';

const STATUS_OPTS = ['active', 'on_hold', 'completed', 'archived'];
const STATUS_STYLE = { active: 'badge-green', on_hold: 'badge-yellow', completed: 'badge-blue', archived: 'badge-gray' };
const EMOJIS = ['🚀', '📱', '⚡', '🔐', '🎯', '🛸', '💡', '🧠', '🔥', '🌊', '📊', '🎨', '🔬', '🏗️', '🎮'];
const COLORS = ['#2563eb', '#7c3aed', '#db2777', '#dc2626', '#ea580c', '#16a34a', '#0891b2', '#d97706'];

export default function ProjectsPage() {
  const { projects, loading, create, remove } = useProjects();
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [showCreate, setShowCreate] = useState(false);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const filtered = projects.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || p.status === statusFilter;
    return matchSearch && matchStatus;
  });

  return (
    <div className="max-w-7xl mx-auto animate-fade-in">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Projects</h1>
          <p className="text-sm text-slate-500">{projects.length} project{projects.length !== 1 ? 's' : ''}</p>
        </div>
        {isAdmin && (
          <button onClick={() => setShowCreate(true)} className="btn btn-primary">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
            New Project
          </button>
        )}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 mb-5">
        <div className="relative flex-1 max-w-xs">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          <input className="input pl-9 py-1.5 text-xs" placeholder="Search projects..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div className="flex items-center gap-1">
          {['all', ...STATUS_OPTS].map(s => (
            <button key={s} onClick={() => setStatusFilter(s)} className={cn('px-3 py-1.5 rounded text-xs font-medium transition-colors', statusFilter === s ? 'bg-blue-600 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50')}>
              {s.charAt(0).toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Project Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => <div key={i} className="h-52 skeleton rounded-lg" />)}
        </div>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon="📁"
          title={search ? 'No projects match your search' : 'No projects yet'}
          subtitle={isAdmin ? 'Create your first project to get started' : 'Ask your admin to add you to a project'}
          action={isAdmin && <button onClick={() => setShowCreate(true)} className="btn btn-primary mt-4">Create Project</button>}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(p => (
            <ProjectCard key={p.id} project={p} isAdmin={isAdmin} onOpen={() => navigate(`/projects/${p.id}`)} onDelete={() => { if (confirm(`Delete "${p.name}"?`)) remove(p.id); }} />
          ))}
        </div>
      )}

      {showCreate && <CreateProjectModal onClose={() => setShowCreate(false)} onCreate={create} />}
    </div>
  );
}

function ProjectCard({ project: p, isAdmin, onOpen, onDelete }) {
  const pct = p.taskCount ? Math.round(p.doneCount / p.taskCount * 100) : 0;
  return (
    <div className="card-hover group p-5" onClick={onOpen}>
      {/* Top */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl" style={{ background: p.color + '22' }}>{p.emoji}</div>
          <div>
            <h3 className="text-sm font-semibold text-slate-900 group-hover:text-blue-600 transition-colors">{p.name}</h3>
            <span className={cn('badge text-[10px]', STATUS_STYLE[p.status])}>{p.status.replace('_', ' ')}</span>
          </div>
        </div>
        {isAdmin && (
          <button onClick={e => { e.stopPropagation(); onDelete(); }} className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-red-50 hover:text-red-500 text-slate-300 transition-all">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
          </button>
        )}
      </div>

      {p.description && <p className="text-xs text-slate-500 line-clamp-2 mb-3">{p.description}</p>}

      {/* Progress */}
      <div className="mb-3">
        <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
          <span>{p.doneCount || 0}/{p.taskCount || 0} tasks</span>
          <span className="font-semibold">{pct}%</span>
        </div>
        <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
          <div className="h-full rounded-full transition-all duration-500" style={{ width: `${pct}%`, background: p.color }} />
        </div>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-100">
        <AvatarGroup users={p.members || []} max={4} size="xs" />
        <div className="flex items-center gap-3 text-[10px] text-slate-400">
          {p.overdueCount > 0 && <span className="text-red-500 font-medium">⚠ {p.overdueCount} overdue</span>}
          {p.due_date && <span>📅 {formatDate(p.due_date)}</span>}
        </div>
      </div>
    </div>
  );
}

function CreateProjectModal({ onClose, onCreate }) {
  const [form, setForm] = useState({ name: '', description: '', emoji: '🚀', color: '#2563eb', start_date: '', due_date: '', client_access: false });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const set = k => e => setForm(f => ({ ...f, [k]: e.target?.value ?? e }));

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = 'Project name is required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      await onCreate(form);
      onClose();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to create project');
    } finally { setLoading(false); }
  };

  return (
    <Modal open title="New Project" onClose={onClose} size="md"
      footer={<>
        <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary" onClick={submit} disabled={loading}>{loading ? <Spinner size="sm" /> : 'Create Project'}</button>
      </>}>
      <div className="space-y-4">
        {/* Emoji picker */}
        <div>
          <label className="label">Icon</label>
          <div className="flex flex-wrap gap-2">
            {EMOJIS.map(e => (
              <button key={e} onClick={() => set('emoji')(e)} className={cn('w-9 h-9 rounded-lg text-lg flex items-center justify-center transition-all', form.emoji === e ? 'bg-blue-100 ring-2 ring-blue-400' : 'hover:bg-slate-100')}>
                {e}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="label">Project Name *</label>
          <input className={cn('input', errors.name && 'input-error')} placeholder="e.g. Marketing Site Redesign" value={form.name} onChange={set('name')} />
          {errors.name && <p className="form-error">{errors.name}</p>}
        </div>

        <div>
          <label className="label">Description</label>
          <textarea className="input resize-none" rows={2} placeholder="What is this project about?" value={form.description} onChange={set('description')} />
        </div>

        <div>
          <label className="label">Color</label>
          <div className="flex gap-2">
            {COLORS.map(c => (
              <button key={c} onClick={() => set('color')(c)} className={cn('w-7 h-7 rounded-full transition-all', form.color === c && 'ring-2 ring-offset-2 ring-slate-400 scale-110')} style={{ background: c }} />
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Start Date</label>
            <input type="date" className="input" value={form.start_date} onChange={set('start_date')} />
          </div>
          <div>
            <label className="label">Due Date</label>
            <input type="date" className="input" value={form.due_date} onChange={set('due_date')} />
          </div>
        </div>

        <label className="flex items-center gap-2 cursor-pointer p-3 rounded-lg border border-slate-200 hover:bg-slate-50">
          <input type="checkbox" className="rounded" checked={form.client_access} onChange={e => set('client_access')(e.target.checked)} />
          <div>
            <div className="text-sm font-medium text-slate-700">Enable client access</div>
            <div className="text-xs text-slate-400">Clients can view project progress via a shareable link</div>
          </div>
        </label>
      </div>
    </Modal>
  );
}
