import { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Avatar, EmptyState, Spinner } from '../../components/common';
import { apiGet } from '../../services/api';
import { cn } from '../../utils';

export default function TeamPage() {
  const { isAdmin } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGet('/users/search', { q: ' ' }).then(r => { setUsers(r.users || []); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  const roleColor = { admin: 'badge-blue', member: 'badge-green', client: 'badge-purple' };

  if (loading) return <div className="flex justify-center py-16"><Spinner size="lg" /></div>;

  return (
    <div className="max-w-4xl mx-auto animate-fade-in">
      <div className="page-header">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Team</h1>
          <p className="text-sm text-slate-500">{users.length} member{users.length !== 1 ? 's' : ''}</p>
        </div>
      </div>
      {users.length === 0
        ? <EmptyState icon="👥" title="No team members found" />
        : <div className="card divide-y divide-slate-100">
            {users.map(u => (
              <div key={u.id} className="flex items-center gap-4 p-4 hover:bg-slate-50 transition-colors">
                <Avatar user={u} size="md" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-slate-900">{u.name}</div>
                  <div className="text-xs text-slate-400">{u.email}</div>
                </div>
                <span className={cn('badge', roleColor[u.role] || 'badge-gray')}>{u.role}</span>
              </div>
            ))}
          </div>
      }
    </div>
  );
}
