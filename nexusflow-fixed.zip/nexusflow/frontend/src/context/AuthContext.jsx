import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { auth } from '../services/firebase';
import { apiGet } from '../services/api';
import { connectSocket, disconnectSocket } from '../services/socket';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState(null);
  const [user, setUser] = useState(null);      // DB user with role
  const [loading, setLoading] = useState(true);

  const fetchDBUser = useCallback(async () => {
    try {
      const { user: dbUser } = await apiGet('/me');
      setUser(dbUser);
      return dbUser;
    } catch {
      return null;
    }
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      if (fbUser) {
        const dbUser = await fetchDBUser();
        if (dbUser) await connectSocket();
      } else {
        setUser(null);
        disconnectSocket();
      }
      setLoading(false);
    });
    return unsub;
  }, [fetchDBUser]);

  const logout = async () => {
    disconnectSocket();
    await signOut(auth);
    setUser(null);
    setFirebaseUser(null);
  };

  const refreshUser = async () => {
    const dbUser = await fetchDBUser();
    return dbUser;
  };

  const isAdmin = user?.role === 'admin';
  const isMember = user?.role === 'member';
  const isClient = user?.role === 'client';

  return (
    <AuthContext.Provider value={{ firebaseUser, user, loading, logout, refreshUser, isAdmin, isMember, isClient }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
