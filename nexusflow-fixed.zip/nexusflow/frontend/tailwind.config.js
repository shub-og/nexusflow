/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: { 50:'#eff6ff', 100:'#dbeafe', 200:'#bfdbfe', 300:'#93c5fd', 400:'#60a5fa', 500:'#3b82f6', 600:'#2563eb', 700:'#1d4ed8', 800:'#1e40af', 900:'#1e3a8a' },
        surface: { DEFAULT:'#ffffff', secondary:'#f8fafc', tertiary:'#f1f5f9', hover:'#f0f4ff' },
        border: { DEFAULT:'#e2e8f0', strong:'#cbd5e1' },
        text: { primary:'#0f172a', secondary:'#475569', muted:'#94a3b8' },
        status: {
          todo: '#64748b', todo_bg: '#f1f5f9',
          in_progress: '#2563eb', in_progress_bg: '#eff6ff',
          in_review: '#7c3aed', in_review_bg: '#f5f3ff',
          done: '#16a34a', done_bg: '#f0fdf4',
          cancelled: '#dc2626', cancelled_bg: '#fef2f2',
        },
        priority: {
          critical: '#dc2626', critical_bg: '#fef2f2',
          high: '#ea580c', high_bg: '#fff7ed',
          medium: '#ca8a04', medium_bg: '#fefce8',
          low: '#16a34a', low_bg: '#f0fdf4',
        }
      },
      fontFamily: { sans: ['Inter var', 'Inter', 'system-ui', 'sans-serif'] },
      boxShadow: {
        card: '0 1px 3px rgba(0,0,0,.08), 0 1px 2px rgba(0,0,0,.06)',
        dropdown: '0 4px 24px rgba(0,0,0,.12), 0 1px 3px rgba(0,0,0,.08)',
        modal: '0 20px 60px rgba(0,0,0,.15)',
      },
      animation: {
        'slide-in': 'slideIn .15s ease-out',
        'fade-in': 'fadeIn .2s ease-out',
      },
      keyframes: {
        slideIn: { from: { opacity: 0, transform: 'translateY(-8px)' }, to: { opacity: 1, transform: 'translateY(0)' } },
        fadeIn: { from: { opacity: 0 }, to: { opacity: 1 } },
      }
    }
  },
  plugins: [],
};
