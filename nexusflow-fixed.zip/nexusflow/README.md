# NexusFlow — Team Task Manager

> Full-Stack SaaS · React + Node.js + PostgreSQL + Firebase · Real-time via Socket.io

---

## 🚀 Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18 + Vite + Tailwind CSS + Recharts |
| Backend | Node.js + Express.js + Socket.io |
| Auth | Firebase Authentication (email + Google) |
| Database | PostgreSQL (Supabase) + Sequelize ORM |
| Email | Nodemailer |
| Jobs | node-cron |
| File Upload | Multer |
| Frontend Deploy | Vercel |
| Backend Deploy | Railway |

---

## 📁 Project Structure

```
nexusflow/
├── backend/
│   ├── src/
│   │   ├── config/       # DB, Firebase, Multer
│   │   ├── controllers/  # Auth, Projects, Tasks, Dashboard, Notifications
│   │   ├── middleware/   # Firebase auth, error handler
│   │   ├── models/       # Sequelize models + associations
│   │   ├── routes/       # All API routes
│   │   ├── services/     # Email, Notifications, Cron
│   │   ├── socket/       # Socket.io handler
│   │   └── server.js     # Entry point
│   ├── uploads/          # File uploads (gitignored)
│   ├── .env.example
│   └── railway.toml
└── frontend/
    ├── src/
    │   ├── components/   # UI components
    │   ├── context/      # AuthContext, NotifContext
    │   ├── hooks/        # useProjects, useTasks, useDashboard
    │   ├── pages/        # Auth, Dashboard, Projects, Board, Team
    │   ├── services/     # api.js, firebase.js, socket.js
    │   ├── styles/       # globals.css
    │   └── utils/        # formatters, helpers
    ├── .env.example
    └── vercel.json
```

---

## ⚡ Quick Start (Local)

### 1. Clone & setup environment

```bash
git clone https://github.com/YOUR_USERNAME/nexusflow.git
cd nexusflow

# Backend
cp backend/.env.example backend/.env
# Fill in your values (Firebase, Supabase, SMTP)

# Frontend
cp frontend/.env.example frontend/.env
# Fill in your Firebase web config
```

### 2. Install dependencies

```bash
# Backend
cd backend && npm install

# Frontend
cd ../frontend && npm install
```

### 3. Setup Supabase (PostgreSQL)

1. Go to [supabase.com](https://supabase.com) → New Project
2. Copy the **Connection String** from Settings > Database
3. Paste into `backend/.env` as `DATABASE_URL`
4. The app will auto-sync tables on first start (dev mode)

### 4. Setup Firebase

1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. New project → Enable **Authentication** (Email/Password + Google)
3. **Frontend config**: Project Settings → Web App → copy config to `frontend/.env`
4. **Backend config**: Project Settings → Service Accounts → Generate Private Key → fill into `backend/.env`

### 5. Run dev servers

```bash
# Terminal 1 - Backend
cd backend && npm run dev
# API: http://localhost:5000

# Terminal 2 - Frontend
cd frontend && npm run dev
# App: http://localhost:3000
```

---

## 🌐 Deploy to Railway (Backend)

```bash
# Install Railway CLI
npm install -g @railway/cli

# Login
railway login

# From /backend directory
cd backend
railway init          # Link/create project
railway up            # Deploy

# Set environment variables in Railway dashboard
# Add all variables from .env.example
```

**Railway env vars to set:**
- `DATABASE_URL` — from Supabase connection string
- `FIREBASE_PROJECT_ID`, `FIREBASE_PRIVATE_KEY`, `FIREBASE_CLIENT_EMAIL`
- `EMAIL_USER`, `EMAIL_PASS`
- `CLIENT_URL` — your Vercel URL

---

## 🌐 Deploy to Vercel (Frontend)

```bash
# Install Vercel CLI
npm install -g vercel

# From /frontend directory
cd frontend
vercel          # Follow prompts

# Set env vars in Vercel dashboard:
# VITE_API_URL = https://your-backend.railway.app/api
# VITE_SOCKET_URL = https://your-backend.railway.app
# VITE_FIREBASE_* = all Firebase web config values
```

---

## 🔐 Role-Based Access

| Feature | Admin | Member | Client |
|---|---|---|---|
| View projects | ✅ All | ✅ Own | ✅ Assigned |
| Create project | ✅ | ✅ | ❌ |
| Add/remove members | ✅ | ❌ | ❌ |
| Create tasks | ✅ | ✅ | ❌ |
| Assign tasks | ✅ | ❌ | ❌ |
| Update task status | ✅ | ✅ Own | ❌ |
| Delete tasks | ✅ | Own only | ❌ |
| View dashboard | ✅ Full | ✅ Own | ✅ Limited |

---

## 📡 API Reference

```
GET     /api/health
GET     /api/me
PUT     /api/me
GET     /api/me/stats
GET     /api/users/search?q=

GET     /api/dashboard

GET     /api/projects
POST    /api/projects
GET     /api/projects/:id
PUT     /api/projects/:id
DELETE  /api/projects/:id
GET     /api/projects/:id/analytics
POST    /api/projects/:id/members
DELETE  /api/projects/:id/members/:userId

GET     /api/tasks?projectId=&status=&priority=&assigneeId=&search=
POST    /api/tasks
GET     /api/tasks/:id
PUT     /api/tasks/:id
DELETE  /api/tasks/:id
PATCH   /api/tasks/reorder
POST    /api/tasks/:id/attach
DELETE  /api/tasks/:id/attach/:attachId
POST    /api/tasks/:id/comments
PUT     /api/tasks/:id/comments/:commentId
DELETE  /api/tasks/:id/comments/:commentId

GET     /api/notifications
POST    /api/notifications/read
DELETE  /api/notifications/:id
```

---

## 🔌 Socket.io Events

| Event | Direction | Description |
|---|---|---|
| `join:project` | Client → Server | Join project room |
| `task:created` | Server → Client | New task broadcast |
| `task:updated` | Server → Client | Task change broadcast |
| `task:deleted` | Server → Client | Task removal broadcast |
| `notification:new` | Server → Client | Real-time notification |
| `comment:new` | Server → Client | New comment on task |
| `user:online` | Server → Client | User joined project |
| `typing:start/stop` | Bidirectional | Comment typing indicator |

---

## 🛠️ GitHub Actions CI (Optional)

Create `.github/workflows/deploy.yml` for auto-deploy on push to main.
Set secrets: `RAILWAY_TOKEN`, `VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID`

---

## 📧 Email Setup (Gmail)

1. Enable 2FA on Gmail
2. Generate App Password: Account → Security → App Passwords
3. Set `EMAIL_USER=your@gmail.com` and `EMAIL_PASS=your-app-password`

---

Built with ❤️ · NexusFlow 2025
