const { admin } = require('../config/firebase');
const { User } = require('../models');

const authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'No token provided' });
    }

    const token = authHeader.split('Bearer ')[1];
    const decoded = await admin.auth().verifyIdToken(token);

    // Find or create user in DB
    let user = await User.findOne({ where: { firebase_uid: decoded.uid } });
    if (!user) {
      user = await User.create({
        firebase_uid: decoded.uid,
        name: decoded.name || decoded.email.split('@')[0],
        email: decoded.email,
        avatar_url: decoded.picture || null,
        role: 'member',
      });
    }

    // Update last_seen
    await user.update({ last_seen: new Date() });

    req.user = user;
    req.firebaseUser = decoded;
    next();
  } catch (err) {
    if (err.code === 'auth/id-token-expired') {
      return res.status(401).json({ error: 'Token expired' });
    }
    return res.status(401).json({ error: 'Invalid token', detail: err.message });
  }
};

const requireRole = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user?.role)) {
    return res.status(403).json({ error: `Access denied. Required role: ${roles.join(' or ')}` });
  }
  next();
};

const requireProjectMember = (projectRole = null) => async (req, res, next) => {
  const { ProjectMember } = require('../models');
  const projectId = req.params.projectId || req.body.project_id;

  if (req.user.role === 'admin') return next();

  const membership = await ProjectMember.findOne({
    where: { project_id: projectId, user_id: req.user.id }
  });

  if (!membership) {
    return res.status(403).json({ error: 'Not a member of this project' });
  }

  if (projectRole && membership.role !== projectRole && membership.role !== 'admin') {
    return res.status(403).json({ error: `Project role '${projectRole}' required` });
  }

  req.membership = membership;
  next();
};

module.exports = { authenticate, requireRole, requireProjectMember };
