const express = require('express');
const { body, query, param } = require('express-validator');
const router = express.Router();

const { authenticate, requireRole, requireProjectMember } = require('../middleware/auth');
const { validate } = require('../middleware/errorHandler');
const upload = require('../config/multer');

const authCtrl = require('../controllers/authController');
const projectCtrl = require('../controllers/projectController');
const taskCtrl = require('../controllers/taskController');
const notifCtrl = require('../controllers/notificationController');
const dashCtrl = require('../controllers/dashboardController');

// ── Health ────────────────────────────────────────────────────────────────────
router.get('/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString(), env: process.env.NODE_ENV }));

// ── Auth / Users ──────────────────────────────────────────────────────────────
router.get('/me', authenticate, authCtrl.getMe);
router.put('/me', authenticate, upload.single('avatar'), authCtrl.updateProfile);
router.get('/me/stats', authenticate, authCtrl.getStats);
router.get('/users/search', authenticate, authCtrl.searchUsers);

// ── Dashboard ─────────────────────────────────────────────────────────────────
router.get('/dashboard', authenticate, dashCtrl.getDashboard);

// ── Projects ──────────────────────────────────────────────────────────────────
router.get('/projects', authenticate, projectCtrl.getProjects);
router.post('/projects', authenticate, requireRole('admin','member'), [body('name').trim().notEmpty().withMessage('Name required'), validate], projectCtrl.createProject);
router.get('/projects/:id', authenticate, projectCtrl.getProject);
router.put('/projects/:id', authenticate, projectCtrl.updateProject);
router.delete('/projects/:id', authenticate, projectCtrl.deleteProject);
router.get('/projects/:id/analytics', authenticate, projectCtrl.getProjectAnalytics);
router.post('/projects/:id/members', authenticate, requireRole('admin'), [body('user_id').notEmpty(), validate], projectCtrl.addMember);
router.delete('/projects/:id/members/:userId', authenticate, requireRole('admin'), projectCtrl.removeMember);

// ── Tasks ─────────────────────────────────────────────────────────────────────
router.get('/tasks', authenticate, taskCtrl.getTasks);
router.post('/tasks', authenticate, [body('title').trim().notEmpty(), body('project_id').notEmpty(), validate], taskCtrl.createTask);
router.patch('/tasks/reorder', authenticate, taskCtrl.reorderTasks);
router.get('/tasks/:id', authenticate, taskCtrl.getTask);
router.put('/tasks/:id', authenticate, taskCtrl.updateTask);
router.delete('/tasks/:id', authenticate, taskCtrl.deleteTask);

// Task attachments
router.post('/tasks/:id/attach', authenticate, upload.single('file'), taskCtrl.uploadAttachment);
router.delete('/tasks/:id/attach/:attachId', authenticate, taskCtrl.deleteAttachment);

// Task comments
router.post('/tasks/:id/comments', authenticate, upload.single('file'), [body('content').trim().notEmpty(), validate], taskCtrl.addComment);
router.put('/tasks/:id/comments/:commentId', authenticate, taskCtrl.updateComment);
router.delete('/tasks/:id/comments/:commentId', authenticate, taskCtrl.deleteComment);

// ── Notifications ─────────────────────────────────────────────────────────────
router.get('/notifications', authenticate, notifCtrl.getNotifications);
router.post('/notifications/read', authenticate, notifCtrl.markRead);
router.delete('/notifications/:id', authenticate, notifCtrl.deleteNotification);

module.exports = router;
