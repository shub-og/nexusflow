require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const path = require('path');

const { sequelize } = require('./models');
const { initFirebase } = require('./config/firebase');
const { setupSocket } = require('./socket');
const { startCronJobs } = require('./services/cronService');
const routes = require('./routes');
const { errorHandler, notFound } = require('./middleware/errorHandler');

const app = express();
const server = http.createServer(app);

// ── Track readiness ───────────────────────────────────────────────────────────
let dbReady = false;
let firebaseReady = false;

// ── Socket.io ─────────────────────────────────────────────────────────────────
const io = new Server(server, {
  cors: {
    origin: (process.env.CLIENT_URL || 'http://localhost:3000').split(','),
    methods: ['GET', 'POST'],
    credentials: true,
  },
  pingTimeout: 60000,
});
app.set('io', io);

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({
  origin: (process.env.CLIENT_URL || 'http://localhost:3000').split(','),
  credentials: true,
}));
app.use(morgan(process.env.NODE_ENV === 'development' ? 'dev' : 'combined'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Rate limiting
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 200, message: 'Too many requests' });
app.use('/api/', limiter);

// Static uploads
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// ── Health check — MUST respond immediately, before DB is ready ───────────────
// Railway healthcheck hits this. It must return 200 even during DB init.
app.get('/api/health', (req, res) => {
  res.status(200).json({
    status: 'ok',
    db: dbReady ? 'connected' : 'connecting',
    firebase: firebaseReady ? 'ready' : 'initializing',
    time: new Date().toISOString(),
    env: process.env.NODE_ENV,
    uptime: Math.round(process.uptime()) + 's',
  });
});

// Root health (some proxies check /)
app.get('/', (req, res) => res.status(200).json({ status: 'ok', service: 'NexusFlow API' }));
app.get('/health', (req, res) => res.status(200).json({ status: 'ok' }));

// ── Routes ────────────────────────────────────────────────────────────────────
app.use('/api', routes);
app.use(notFound);
app.use(errorHandler);

// ── Bootstrap ─────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;

// Start HTTP server FIRST so Railway healthcheck passes immediately
server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n🚀 NexusFlow API listening on port ${PORT}`);
  console.log(`   ENV: ${process.env.NODE_ENV}`);
  // Now init everything else asynchronously
  initServices();
});

server.on('error', (err) => {
  console.error('❌ Server error:', err);
  process.exit(1);
});

async function initServices() {
  // ── Firebase ────────────────────────────────────────────────────────────────
  try {
    initFirebase();
    firebaseReady = true;
    console.log('✅ Firebase ready');
  } catch (err) {
    console.error('⚠️  Firebase init failed (auth endpoints will not work):', err.message);
  }

  // ── Database ─────────────────────────────────────────────────────────────────
  let retries = 5;
  while (retries > 0) {
    try {
      await sequelize.authenticate();
      console.log('✅ Database connected');

      // Always sync in production too — creates tables if they don't exist
      await sequelize.sync({ alter: false, force: false });
      console.log('✅ Database tables synced');

      dbReady = true;
      break;
    } catch (err) {
      retries--;
      console.error(`❌ DB connection failed (${retries} retries left):`, err.message);
      if (retries === 0) {
        console.error('❌ Could not connect to database after 5 attempts');
        // Don't exit — app still serves health check, just DB endpoints fail
      } else {
        await new Promise(r => setTimeout(r, 3000)); // wait 3s before retry
      }
    }
  }

  // ── Uploads dir ──────────────────────────────────────────────────────────────
  try {
    const uploadsDir = path.join(__dirname, '../uploads');
    require('fs').mkdirSync(uploadsDir, { recursive: true });
  } catch {}

  // ── Socket & Cron ────────────────────────────────────────────────────────────
  if (dbReady && firebaseReady) {
    try {
      setupSocket(io);
      console.log('✅ Socket.io ready');
    } catch (err) {
      console.error('⚠️  Socket setup failed:', err.message);
    }
    try {
      startCronJobs(io);
      console.log('✅ Cron jobs started');
    } catch (err) {
      console.error('⚠️  Cron jobs failed:', err.message);
    }
  }

  console.log('\n✨ NexusFlow fully initialized\n');
}

module.exports = { app, io };
