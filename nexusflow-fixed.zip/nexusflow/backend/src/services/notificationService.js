const { Notification, User } = require('../models');
const { sendEmail } = require('./emailService');

const createNotification = async ({ userId, type, title, message, data = {} }, io = null) => {
  try {
    const notification = await Notification.create({ user_id: userId, type, title, message, data });

    // Push via Socket.io
    if (io) {
      io.to(`user:${userId}`).emit('notification:new', notification);
    }

    // Send email if user prefers it
    const user = await User.findByPk(userId);
    if (user?.notification_prefs?.email) {
      const emailMap = {
        task_assigned: { template: 'taskAssigned', send: user.notification_prefs.task_assigned },
        task_due: { template: 'overdueReminder', send: user.notification_prefs.task_due },
        project_invite: { template: 'projectInvite', send: user.notification_prefs.project_update },
      };
      const emailConf = emailMap[type];
      if (emailConf?.send && emailConf.template && data.emailData) {
        await sendEmail(user.email, emailConf.template, data.emailData);
      }
    }

    return notification;
  } catch (err) {
    console.error('Notification error:', err.message);
  }
};

const notifyTaskAssigned = async (task, assignee, assigner, project, io) => {
  await createNotification({
    userId: assignee.id,
    type: 'task_assigned',
    title: 'New task assigned',
    message: `${assigner.name} assigned you "${task.title}"`,
    data: {
      task_id: task.id,
      project_id: project.id,
      emailData: {
        taskTitle: task.title,
        taskDesc: task.description,
        taskId: task.id,
        projectName: project.name,
        priority: task.priority,
        dueDate: task.due_date,
        assignedBy: assigner.name,
      }
    }
  }, io);
};

const notifyProjectInvite = async (member, project, inviter, io) => {
  await createNotification({
    userId: member.id,
    type: 'project_invite',
    title: 'Added to project',
    message: `${inviter.name} added you to "${project.name}"`,
    data: {
      project_id: project.id,
      emailData: {
        projectName: project.name,
        projectId: project.id,
        invitedBy: inviter.name,
        role: 'member',
      }
    }
  }, io);
};

module.exports = { createNotification, notifyTaskAssigned, notifyProjectInvite };
