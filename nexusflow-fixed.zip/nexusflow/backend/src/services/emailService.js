const nodemailer = require('nodemailer');
require('dotenv').config();

let transporter;

const getTransporter = () => {
  if (transporter) return transporter;
  transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.EMAIL_PORT) || 587,
    secure: false,
    auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS },
    tls: { rejectUnauthorized: false }
  });
  return transporter;
};

const emailTemplates = {
  taskAssigned: (data) => ({
    subject: `[NexusFlow] Task assigned: ${data.taskTitle}`,
    html: `
      <div style="font-family:Inter,sans-serif;max-width:560px;margin:0 auto;background:#fff;border-radius:8px;overflow:hidden;border:1px solid #e2e8f0">
        <div style="background:#2563eb;padding:24px 32px">
          <h1 style="color:white;margin:0;font-size:20px">📋 NexusFlow</h1>
        </div>
        <div style="padding:32px">
          <h2 style="color:#1e293b;margin-top:0">New task assigned to you</h2>
          <div style="background:#f8fafc;border-left:4px solid #2563eb;padding:16px 20px;border-radius:4px;margin:16px 0">
            <p style="margin:0;font-size:16px;color:#1e293b;font-weight:600">${data.taskTitle}</p>
            <p style="margin:8px 0 0;color:#64748b;font-size:14px">${data.taskDesc || 'No description provided'}</p>
          </div>
          <table style="width:100%;border-collapse:collapse;margin:16px 0">
            <tr><td style="padding:8px 0;color:#64748b;font-size:14px;width:120px">Project</td><td style="color:#1e293b;font-weight:500;font-size:14px">${data.projectName}</td></tr>
            <tr><td style="padding:8px 0;color:#64748b;font-size:14px">Priority</td><td style="color:#1e293b;font-weight:500;font-size:14px">${data.priority}</td></tr>
            <tr><td style="padding:8px 0;color:#64748b;font-size:14px">Due Date</td><td style="color:#1e293b;font-weight:500;font-size:14px">${data.dueDate || 'Not set'}</td></tr>
            <tr><td style="padding:8px 0;color:#64748b;font-size:14px">Assigned by</td><td style="color:#1e293b;font-weight:500;font-size:14px">${data.assignedBy}</td></tr>
          </table>
          <a href="${process.env.FRONTEND_URL}/tasks/${data.taskId}" style="display:inline-block;background:#2563eb;color:white;padding:12px 24px;text-decoration:none;border-radius:6px;font-weight:600;margin-top:8px">View Task →</a>
        </div>
        <div style="padding:16px 32px;background:#f8fafc;text-align:center;font-size:12px;color:#94a3b8">
          <a href="${process.env.FRONTEND_URL}/settings/notifications" style="color:#94a3b8">Manage notification preferences</a>
        </div>
      </div>`,
  }),

  overdueReminder: (data) => ({
    subject: `[NexusFlow] ⚠️ ${data.taskCount} task(s) overdue`,
    html: `
      <div style="font-family:Inter,sans-serif;max-width:560px;margin:0 auto;background:#fff;border-radius:8px;overflow:hidden;border:1px solid #e2e8f0">
        <div style="background:#dc2626;padding:24px 32px"><h1 style="color:white;margin:0;font-size:20px">⚠️ NexusFlow — Overdue Alert</h1></div>
        <div style="padding:32px">
          <h2 style="color:#1e293b;margin-top:0">You have ${data.taskCount} overdue task(s)</h2>
          ${data.tasks.map(t => `<div style="border:1px solid #fee2e2;border-radius:6px;padding:12px 16px;margin:8px 0;background:#fff5f5">
            <p style="margin:0;font-weight:600;color:#1e293b">${t.title}</p>
            <p style="margin:4px 0 0;font-size:13px;color:#dc2626">Due: ${t.due_date} · Project: ${t.project?.name}</p>
          </div>`).join('')}
          <a href="${process.env.FRONTEND_URL}/tasks" style="display:inline-block;background:#dc2626;color:white;padding:12px 24px;text-decoration:none;border-radius:6px;font-weight:600;margin-top:16px">View All Tasks →</a>
        </div>
      </div>`,
  }),

  projectInvite: (data) => ({
    subject: `[NexusFlow] You've been added to ${data.projectName}`,
    html: `
      <div style="font-family:Inter,sans-serif;max-width:560px;margin:0 auto;background:#fff;border-radius:8px;overflow:hidden;border:1px solid #e2e8f0">
        <div style="background:#2563eb;padding:24px 32px"><h1 style="color:white;margin:0">📋 NexusFlow</h1></div>
        <div style="padding:32px">
          <h2 style="color:#1e293b;margin-top:0">You've been added to a project</h2>
          <p style="color:#475569"><strong>${data.invitedBy}</strong> added you to <strong>${data.projectName}</strong> as a <strong>${data.role}</strong>.</p>
          <a href="${process.env.FRONTEND_URL}/projects/${data.projectId}" style="display:inline-block;background:#2563eb;color:white;padding:12px 24px;text-decoration:none;border-radius:6px;font-weight:600">Open Project →</a>
        </div>
      </div>`,
  }),
};

const sendEmail = async (to, templateKey, data) => {
  try {
    if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
      console.log(`📧 [DEV] Email skipped (no SMTP config): ${templateKey} → ${to}`);
      return;
    }
    const template = emailTemplates[templateKey](data);
    await getTransporter().sendMail({
      from: process.env.EMAIL_FROM || '"NexusFlow" <noreply@nexusflow.app>',
      to,
      subject: template.subject,
      html: template.html,
    });
    console.log(`📧 Email sent: ${templateKey} → ${to}`);
  } catch (err) {
    console.error(`📧 Email error (${templateKey}):`, err.message);
  }
};

module.exports = { sendEmail };
