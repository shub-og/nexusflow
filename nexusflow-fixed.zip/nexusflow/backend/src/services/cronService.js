const cron = require('node-cron');
const { Op } = require('sequelize');
const { Task, User, Project, Notification } = require('../models');
const { sendEmail } = require('./emailService');

const startCronJobs = (io) => {
  // Every hour: check for overdue tasks and send notifications
  cron.schedule('0 * * * *', async () => {
    console.log('⏰ Cron: Checking overdue tasks...');
    try {
      const overdueTasks = await Task.findAll({
        where: {
          due_date: { [Op.lt]: new Date() },
          status: { [Op.notIn]: ['done', 'cancelled'] },
          assignee_id: { [Op.ne]: null },
        },
        include: [
          { model: User, as: 'assignee' },
          { model: Project, as: 'project' },
        ],
      });

      // Group by assignee
      const byUser = {};
      for (const task of overdueTasks) {
        if (!task.assignee) continue;
        const uid = task.assignee_id;
        if (!byUser[uid]) byUser[uid] = { user: task.assignee, tasks: [] };
        byUser[uid].tasks.push(task);
      }

      for (const [uid, { user, tasks }] of Object.entries(byUser)) {
        // Create in-app notification
        const existing = await Notification.findOne({
          where: {
            user_id: uid,
            type: 'overdue_reminder',
            created_at: { [Op.gte]: new Date(Date.now() - 24 * 60 * 60 * 1000) }
          }
        });

        if (!existing) {
          const notif = await Notification.create({
            user_id: uid,
            type: 'overdue_reminder',
            title: `${tasks.length} task(s) overdue`,
            message: `You have ${tasks.length} overdue task(s) that need attention`,
            data: { task_ids: tasks.map(t => t.id) }
          });

          if (io) io.to(`user:${uid}`).emit('notification:new', notif);

          if (user.notification_prefs?.email && user.notification_prefs?.task_due) {
            await sendEmail(user.email, 'overdueReminder', {
              taskCount: tasks.length,
              tasks: tasks.map(t => ({ title: t.title, due_date: t.due_date, project: t.project }))
            });
          }
        }
      }

      console.log(`✅ Cron: Processed ${overdueTasks.length} overdue tasks for ${Object.keys(byUser).length} users`);
    } catch (err) {
      console.error('❌ Cron error:', err.message);
    }
  });

  // Daily at 9am: send daily digest
  cron.schedule('0 9 * * *', async () => {
    console.log('⏰ Cron: Daily digest...');
    // Future: send daily summary emails
  });

  console.log('✅ Cron jobs started');
};

module.exports = { startCronJobs };
