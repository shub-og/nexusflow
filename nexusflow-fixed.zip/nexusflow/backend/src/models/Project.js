const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Project = sequelize.define('Project', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  name: { type: DataTypes.STRING(150), allowNull: false },
  description: { type: DataTypes.TEXT, allowNull: true },
  emoji: { type: DataTypes.STRING(10), defaultValue: '🚀' },
  color: { type: DataTypes.STRING(7), defaultValue: '#2563eb' },
  status: { type: DataTypes.ENUM('active', 'on_hold', 'completed', 'archived'), defaultValue: 'active' },
  owner_id: { type: DataTypes.UUID, allowNull: false },
  start_date: { type: DataTypes.DATEONLY, allowNull: true },
  due_date: { type: DataTypes.DATEONLY, allowNull: true },
  client_access: { type: DataTypes.BOOLEAN, defaultValue: false },
  client_token: { type: DataTypes.STRING, allowNull: true },
  settings: { type: DataTypes.JSONB, defaultValue: {} },
}, { tableName: 'projects', underscored: true });

module.exports = Project;
