const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const User = sequelize.define('User', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  firebase_uid: { type: DataTypes.STRING, unique: true, allowNull: false },
  name: { type: DataTypes.STRING(100), allowNull: false },
  email: { type: DataTypes.STRING(255), unique: true, allowNull: false },
  avatar_url: { type: DataTypes.TEXT, allowNull: true },
  role: { type: DataTypes.ENUM('admin', 'member', 'client'), defaultValue: 'member' },
  is_active: { type: DataTypes.BOOLEAN, defaultValue: true },
  last_seen: { type: DataTypes.DATE, allowNull: true },
  notification_prefs: {
    type: DataTypes.JSONB,
    defaultValue: { email: true, in_app: true, task_assigned: true, task_due: true, project_update: true }
  },
}, { tableName: 'users', underscored: true });

module.exports = User;
