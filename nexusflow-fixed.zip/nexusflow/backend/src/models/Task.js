const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Task = sequelize.define('Task', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  title: { type: DataTypes.STRING(255), allowNull: false },
  description: { type: DataTypes.TEXT, allowNull: true },
  status: {
    type: DataTypes.ENUM('todo', 'in_progress', 'in_review', 'done', 'cancelled'),
    defaultValue: 'todo'
  },
  priority: { type: DataTypes.ENUM('critical', 'high', 'medium', 'low'), defaultValue: 'medium' },
  project_id: { type: DataTypes.UUID, allowNull: false },
  created_by: { type: DataTypes.UUID, allowNull: false },
  assignee_id: { type: DataTypes.UUID, allowNull: true },
  reporter_id: { type: DataTypes.UUID, allowNull: true },
  parent_task_id: { type: DataTypes.UUID, allowNull: true },
  due_date: { type: DataTypes.DATEONLY, allowNull: true },
  start_date: { type: DataTypes.DATEONLY, allowNull: true },
  estimated_hours: { type: DataTypes.FLOAT, allowNull: true },
  logged_hours: { type: DataTypes.FLOAT, defaultValue: 0 },
  position: { type: DataTypes.INTEGER, defaultValue: 0 },
  labels: { type: DataTypes.ARRAY(DataTypes.STRING), defaultValue: [] },
  attachments: { type: DataTypes.JSONB, defaultValue: [] },
  checklist: { type: DataTypes.JSONB, defaultValue: [] },
  completed_at: { type: DataTypes.DATE, allowNull: true },
  is_overdue: {
    type: DataTypes.VIRTUAL,
    get() {
      return this.due_date && new Date(this.due_date) < new Date() && this.status !== 'done';
    }
  },
}, { tableName: 'tasks', underscored: true });

module.exports = Task;
