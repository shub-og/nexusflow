const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Comment = sequelize.define('Comment', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  task_id: { type: DataTypes.UUID, allowNull: false },
  user_id: { type: DataTypes.UUID, allowNull: false },
  content: { type: DataTypes.TEXT, allowNull: false },
  attachments: { type: DataTypes.JSONB, defaultValue: [] },
  is_edited: { type: DataTypes.BOOLEAN, defaultValue: false },
}, { tableName: 'comments', underscored: true });

const Notification = sequelize.define('Notification', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  user_id: { type: DataTypes.UUID, allowNull: false },
  type: {
    type: DataTypes.ENUM('task_assigned', 'task_due', 'task_commented', 'task_status_changed',
      'project_invite', 'project_update', 'mention', 'overdue_reminder'),
    allowNull: false
  },
  title: { type: DataTypes.STRING(255), allowNull: false },
  message: { type: DataTypes.TEXT, allowNull: false },
  data: { type: DataTypes.JSONB, defaultValue: {} },
  is_read: { type: DataTypes.BOOLEAN, defaultValue: false },
  read_at: { type: DataTypes.DATE, allowNull: true },
}, { tableName: 'notifications', underscored: true });

const Activity = sequelize.define('Activity', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  project_id: { type: DataTypes.UUID, allowNull: true },
  task_id: { type: DataTypes.UUID, allowNull: true },
  user_id: { type: DataTypes.UUID, allowNull: false },
  action: { type: DataTypes.STRING(100), allowNull: false },
  entity_type: { type: DataTypes.STRING(50), allowNull: false },
  entity_id: { type: DataTypes.UUID, allowNull: true },
  meta: { type: DataTypes.JSONB, defaultValue: {} },
}, { tableName: 'activities', underscored: true });

module.exports = { Comment, Notification, Activity };
