const { Project, ProjectMember, User, Task, Activity } = require('../models');
const { notifyProjectInvite } = require('../services/notificationService');
const { emitTaskUpdate } = require('../socket');
const { v4: uuidv4 } = require('uuid');
const { Op } = require('sequelize');

const memberInclude = { model: User, as: 'members', attributes: ['id','name','email','avatar_url','role'], through: { attributes: ['role','joined_at'] } };
const taskCountSubquery = (projectId) => Task.count({ where: { project_id: projectId } });

// GET /projects
const getProjects = async (req, res, next) => {
  try {
    let projects;
    if (req.user.role === 'admin') {
      projects = await Project.findAll({ include: [memberInclude, { model: User, as: 'owner', attributes: ['id','name','avatar_url'] }], order: [['created_at', 'DESC']] });
    } else {
      const memberships = await ProjectMember.findAll({ where: { user_id: req.user.id } });
      const ids = memberships.map(m => m.project_id);
      projects = await Project.findAll({ where: { id: { [Op.in]: ids } }, include: [memberInclude, { model: User, as: 'owner', attributes: ['id','name','avatar_url'] }], order: [['created_at', 'DESC']] });
    }
    // Add task counts
    const withCounts = await Promise.all(projects.map(async p => {
      const [total, done, overdue] = await Promise.all([
        Task.count({ where: { project_id: p.id } }),
        Task.count({ where: { project_id: p.id, status: 'done' } }),
        Task.count({ where: { project_id: p.id, due_date: { [Op.lt]: new Date() }, status: { [Op.notIn]: ['done','cancelled'] } } }),
      ]);
      return { ...p.toJSON(), taskCount: total, doneCount: done, overdueCount: overdue };
    }));
    res.json({ projects: withCounts });
  } catch (err) { next(err); }
};

// GET /projects/:id
const getProject = async (req, res, next) => {
  try {
    const project = await Project.findByPk(req.params.id, {
      include: [
        memberInclude,
        { model: User, as: 'owner', attributes: ['id','name','avatar_url'] },
        { model: Activity, as: 'activities', limit: 20, order: [['created_at','DESC']], include: [{ model: User, as: 'actor', attributes: ['id','name','avatar_url'] }] },
      ]
    });
    if (!project) return res.status(404).json({ error: 'Project not found' });
    res.json({ project });
  } catch (err) { next(err); }
};

// POST /projects
const createProject = async (req, res, next) => {
  try {
    const { name, description, emoji, color, start_date, due_date, client_access } = req.body;
    const project = await Project.create({
      name, description, emoji: emoji || '🚀', color: color || '#2563eb',
      start_date, due_date, owner_id: req.user.id,
      client_access: !!client_access,
      client_token: client_access ? uuidv4() : null,
    });
    // Add creator as admin member
    await ProjectMember.create({ project_id: project.id, user_id: req.user.id, role: 'admin' });
    await Activity.create({ project_id: project.id, user_id: req.user.id, action: 'created project', entity_type: 'project', entity_id: project.id, meta: { name } });
    res.status(201).json({ project, message: 'Project created' });
  } catch (err) { next(err); }
};

// PUT /projects/:id
const updateProject = async (req, res, next) => {
  try {
    const project = await Project.findByPk(req.params.id);
    if (!project) return res.status(404).json({ error: 'Not found' });
    if (project.owner_id !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    await project.update(req.body);
    res.json({ project, message: 'Updated' });
  } catch (err) { next(err); }
};

// DELETE /projects/:id
const deleteProject = async (req, res, next) => {
  try {
    const project = await Project.findByPk(req.params.id);
    if (!project) return res.status(404).json({ error: 'Not found' });
    if (project.owner_id !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    await project.destroy();
    res.json({ message: 'Project deleted' });
  } catch (err) { next(err); }
};

// POST /projects/:id/members
const addMember = async (req, res, next) => {
  try {
    const { user_id, role = 'member' } = req.body;
    const [membership, created] = await ProjectMember.findOrCreate({
      where: { project_id: req.params.id, user_id },
      defaults: { role, invited_by: req.user.id }
    });
    if (!created) return res.status(409).json({ error: 'Already a member' });

    const [project, member] = await Promise.all([Project.findByPk(req.params.id), User.findByPk(user_id)]);
    const io = req.app.get('io');
    await notifyProjectInvite(member, project, req.user, io);
    await Activity.create({ project_id: req.params.id, user_id: req.user.id, action: 'added member', entity_type: 'user', entity_id: user_id, meta: { name: member.name } });

    res.status(201).json({ membership, message: `${member.name} added to project` });
  } catch (err) { next(err); }
};

// DELETE /projects/:id/members/:userId
const removeMember = async (req, res, next) => {
  try {
    const deleted = await ProjectMember.destroy({ where: { project_id: req.params.id, user_id: req.params.userId } });
    if (!deleted) return res.status(404).json({ error: 'Member not found' });
    res.json({ message: 'Member removed' });
  } catch (err) { next(err); }
};

// GET /projects/:id/analytics
const getProjectAnalytics = async (req, res, next) => {
  try {
    const pid = req.params.id;
    const tasks = await Task.findAll({
      where: { project_id: pid },
      include: [{ model: User, as: 'assignee', attributes: ['id','name','avatar_url'] }]
    });

    const byStatus = { todo: 0, in_progress: 0, in_review: 0, done: 0, cancelled: 0 };
    const byPriority = { critical: 0, high: 0, medium: 0, low: 0 };
    const byUser = {};

    for (const t of tasks) {
      byStatus[t.status] = (byStatus[t.status] || 0) + 1;
      byPriority[t.priority] = (byPriority[t.priority] || 0) + 1;
      if (t.assignee) {
        const uid = t.assignee_id;
        if (!byUser[uid]) byUser[uid] = { user: { id: t.assignee.id, name: t.assignee.name, avatar: t.assignee.avatar_url }, total: 0, done: 0 };
        byUser[uid].total++;
        if (t.status === 'done') byUser[uid].done++;
      }
    }

    const overdue = tasks.filter(t => t.due_date && new Date(t.due_date) < new Date() && t.status !== 'done').length;

    res.json({
      totalTasks: tasks.length,
      byStatus,
      byPriority,
      byUser: Object.values(byUser),
      overdueTasks: overdue,
      completionRate: tasks.length ? Math.round(byStatus.done / tasks.length * 100) : 0,
    });
  } catch (err) { next(err); }
};

module.exports = { getProjects, getProject, createProject, updateProject, deleteProject, addMember, removeMember, getProjectAnalytics };
