const { Task, User, Project, Comment, Activity, ProjectMember } = require('../models');
const { notifyTaskAssigned } = require('../services/notificationService');
const { emitTaskUpdate } = require('../socket');
const { Op } = require('sequelize');
const path = require('path');
const fs = require('fs');

const taskInclude = [
  { model: User, as: 'assignee', attributes: ['id','name','email','avatar_url'] },
  { model: User, as: 'creator', attributes: ['id','name','avatar_url'] },
  { model: Project, as: 'project', attributes: ['id','name','emoji','color'] },
  { model: Task, as: 'subtasks', attributes: ['id','title','status','priority'] },
];

// GET /tasks?projectId=&status=&priority=&assigneeId=&search=&overdue=
const getTasks = async (req, res, next) => {
  try {
    const { projectId, status, priority, assigneeId, search, overdue, page = 1, limit = 50 } = req.query;
    const where = { parent_task_id: null }; // top-level tasks only

    if (projectId) where.project_id = projectId;
    if (status) where.status = status;
    if (priority) where.priority = priority;
    if (assigneeId) where.assignee_id = assigneeId;
    if (search) where.title = { [Op.iLike]: `%${search}%` };
    if (overdue === 'true') {
      where.due_date = { [Op.lt]: new Date() };
      where.status = { [Op.notIn]: ['done', 'cancelled'] };
    }

    // Non-admins see only their project tasks
    if (req.user.role !== 'admin') {
      const memberships = await ProjectMember.findAll({ where: { user_id: req.user.id } });
      where.project_id = { [Op.in]: memberships.map(m => m.project_id) };
    }

    const { count, rows: tasks } = await Task.findAndCountAll({
      where,
      include: taskInclude,
      order: [['position', 'ASC'], ['created_at', 'DESC']],
      limit: parseInt(limit),
      offset: (parseInt(page) - 1) * parseInt(limit),
    });

    res.json({ tasks, total: count, page: parseInt(page), pages: Math.ceil(count / parseInt(limit)) });
  } catch (err) { next(err); }
};

// GET /tasks/:id
const getTask = async (req, res, next) => {
  try {
    const task = await Task.findByPk(req.params.id, {
      include: [
        ...taskInclude,
        { model: Comment, as: 'comments', include: [{ model: User, as: 'author', attributes: ['id','name','avatar_url'] }], order: [['created_at','ASC']] },
      ]
    });
    if (!task) return res.status(404).json({ error: 'Task not found' });
    res.json({ task });
  } catch (err) { next(err); }
};

// POST /tasks
const createTask = async (req, res, next) => {
  try {
    const { title, description, status, priority, project_id, assignee_id, due_date, start_date, estimated_hours, labels, parent_task_id } = req.body;

    const maxPos = await Task.max('position', { where: { project_id, status: status || 'todo' } });
    const task = await Task.create({
      title, description, status: status || 'todo', priority: priority || 'medium',
      project_id, created_by: req.user.id, assignee_id: assignee_id || null,
      reporter_id: req.user.id, due_date, start_date, estimated_hours,
      labels: labels || [], parent_task_id: parent_task_id || null,
      position: (maxPos || 0) + 1,
    });

    const fullTask = await Task.findByPk(task.id, { include: taskInclude });

    // Notify assignee
    if (assignee_id && assignee_id !== req.user.id) {
      const [assignee, project] = await Promise.all([User.findByPk(assignee_id), Project.findByPk(project_id)]);
      const io = req.app.get('io');
      await notifyTaskAssigned(task, assignee, req.user, project, io);
    }

    await Activity.create({ project_id, task_id: task.id, user_id: req.user.id, action: 'created task', entity_type: 'task', entity_id: task.id, meta: { title } });

    const io = req.app.get('io');
    emitTaskUpdate(io, project_id, 'task:created', fullTask);

    res.status(201).json({ task: fullTask, message: 'Task created' });
  } catch (err) { next(err); }
};

// PUT /tasks/:id
const updateTask = async (req, res, next) => {
  try {
    const task = await Task.findByPk(req.params.id);
    if (!task) return res.status(404).json({ error: 'Task not found' });

    const oldStatus = task.status;
    const oldAssignee = task.assignee_id;
    const updates = { ...req.body };

    if (updates.status === 'done' && oldStatus !== 'done') updates.completed_at = new Date();
    if (updates.status && updates.status !== 'done') updates.completed_at = null;

    await task.update(updates);
    const fullTask = await Task.findByPk(task.id, { include: taskInclude });

    // Notify new assignee
    if (updates.assignee_id && updates.assignee_id !== oldAssignee) {
      const [assignee, project] = await Promise.all([User.findByPk(updates.assignee_id), Project.findByPk(task.project_id)]);
      if (assignee && project) {
        const io = req.app.get('io');
        await notifyTaskAssigned(task, assignee, req.user, project, io);
      }
    }

    const meta = {};
    if (updates.status && updates.status !== oldStatus) meta.status_change = { from: oldStatus, to: updates.status };

    await Activity.create({ project_id: task.project_id, task_id: task.id, user_id: req.user.id, action: 'updated task', entity_type: 'task', entity_id: task.id, meta: { ...meta, title: task.title } });

    const io = req.app.get('io');
    emitTaskUpdate(io, task.project_id, 'task:updated', fullTask);

    res.json({ task: fullTask, message: 'Task updated' });
  } catch (err) { next(err); }
};

// DELETE /tasks/:id
const deleteTask = async (req, res, next) => {
  try {
    const task = await Task.findByPk(req.params.id);
    if (!task) return res.status(404).json({ error: 'Not found' });
    if (task.created_by !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });

    const io = req.app.get('io');
    emitTaskUpdate(io, task.project_id, 'task:deleted', { id: task.id, project_id: task.project_id });

    await task.destroy();
    res.json({ message: 'Task deleted' });
  } catch (err) { next(err); }
};

// POST /tasks/:id/attach
const uploadAttachment = async (req, res, next) => {
  try {
    const task = await Task.findByPk(req.params.id);
    if (!task) return res.status(404).json({ error: 'Not found' });
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

    const attachment = {
      id: require('uuid').v4(),
      filename: req.file.originalname,
      path: `/uploads/${req.file.filename}`,
      size: req.file.size,
      mimetype: req.file.mimetype,
      uploadedBy: req.user.id,
      uploadedAt: new Date().toISOString(),
    };

    const attachments = [...(task.attachments || []), attachment];
    await task.update({ attachments });

    const io = req.app.get('io');
    emitTaskUpdate(io, task.project_id, 'task:updated', { id: task.id, attachments });

    res.json({ attachment, message: 'File uploaded' });
  } catch (err) { next(err); }
};

// DELETE /tasks/:id/attach/:attachId
const deleteAttachment = async (req, res, next) => {
  try {
    const task = await Task.findByPk(req.params.id);
    if (!task) return res.status(404).json({ error: 'Not found' });

    const attach = task.attachments.find(a => a.id === req.params.attachId);
    if (!attach) return res.status(404).json({ error: 'Attachment not found' });

    const filePath = path.join(__dirname, '../..', attach.path);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

    await task.update({ attachments: task.attachments.filter(a => a.id !== req.params.attachId) });
    res.json({ message: 'Attachment deleted' });
  } catch (err) { next(err); }
};

// POST /tasks/:id/comments
const addComment = async (req, res, next) => {
  try {
    const task = await Task.findByPk(req.params.id);
    if (!task) return res.status(404).json({ error: 'Not found' });

    const attachments = [];
    if (req.file) {
      attachments.push({ filename: req.file.originalname, path: `/uploads/${req.file.filename}`, size: req.file.size });
    }

    const comment = await Comment.create({ task_id: task.id, user_id: req.user.id, content: req.body.content, attachments });
    const full = await Comment.findByPk(comment.id, { include: [{ model: User, as: 'author', attributes: ['id','name','avatar_url'] }] });

    const io = req.app.get('io');
    io.to(`task:${task.id}`).emit('comment:new', full);
    emitTaskUpdate(io, task.project_id, 'task:commented', { taskId: task.id, comment: full });

    res.status(201).json({ comment: full });
  } catch (err) { next(err); }
};

// PUT /tasks/:id/comments/:commentId
const updateComment = async (req, res, next) => {
  try {
    const comment = await Comment.findByPk(req.params.commentId);
    if (!comment) return res.status(404).json({ error: 'Not found' });
    if (comment.user_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
    await comment.update({ content: req.body.content, is_edited: true });
    res.json({ comment });
  } catch (err) { next(err); }
};

// DELETE /tasks/:id/comments/:commentId
const deleteComment = async (req, res, next) => {
  try {
    const comment = await Comment.findByPk(req.params.commentId);
    if (!comment) return res.status(404).json({ error: 'Not found' });
    if (comment.user_id !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    await comment.destroy();
    res.json({ message: 'Comment deleted' });
  } catch (err) { next(err); }
};

// PATCH /tasks/reorder
const reorderTasks = async (req, res, next) => {
  try {
    const { tasks } = req.body; // [{id, position, status}]
    await Promise.all(tasks.map(({ id, position, status }) =>
      Task.update({ position, status }, { where: { id } })
    ));
    res.json({ message: 'Reordered' });
  } catch (err) { next(err); }
};

module.exports = { getTasks, getTask, createTask, updateTask, deleteTask, uploadAttachment, deleteAttachment, addComment, updateComment, deleteComment, reorderTasks };
