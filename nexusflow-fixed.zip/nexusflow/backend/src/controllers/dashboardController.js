const { Task, Project, User, ProjectMember, Activity } = require('../models');
const { Op, fn, col, literal } = require('sequelize');

const getDashboard = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const isAdmin = req.user.role === 'admin';

    // Get projects user belongs to
    let projectIds;
    if (isAdmin) {
      const projects = await Project.findAll({ attributes: ['id'] });
      projectIds = projects.map(p => p.id);
    } else {
      const memberships = await ProjectMember.findAll({ where: { user_id: userId } });
      projectIds = memberships.map(m => m.project_id);
    }

    const taskWhere = isAdmin ? {} : { project_id: { [Op.in]: projectIds } };
    const myTaskWhere = { ...taskWhere, assignee_id: userId };

    const [
      totalTasks, doneTasks, inProgressTasks, todoTasks, overdueTasks,
      totalProjects, activeProjects,
      recentActivity, teamMembers,
    ] = await Promise.all([
      Task.count({ where: taskWhere }),
      Task.count({ where: { ...taskWhere, status: 'done' } }),
      Task.count({ where: { ...taskWhere, status: 'in_progress' } }),
      Task.count({ where: { ...taskWhere, status: 'todo' } }),
      Task.count({ where: { ...taskWhere, due_date: { [Op.lt]: new Date() }, status: { [Op.notIn]: ['done','cancelled'] } } }),
      Project.count({ where: isAdmin ? {} : { id: { [Op.in]: projectIds } } }),
      Project.count({ where: { ...(isAdmin ? {} : { id: { [Op.in]: projectIds } }), status: 'active' } }),
      Activity.findAll({ where: { project_id: { [Op.in]: projectIds } }, include: [{ model: User, as: 'actor', attributes: ['id','name','avatar_url'] }], order: [['created_at','DESC']], limit: 15 }),
      isAdmin ? User.count({ where: { is_active: true } }) : ProjectMember.count({ where: { project_id: { [Op.in]: projectIds } } }),
    ]);

    // Tasks by user (for bar chart)
    const tasksByUser = await Task.findAll({
      attributes: ['assignee_id', [fn('COUNT', col('id')), 'total'], [fn('SUM', literal("CASE WHEN status = 'done' THEN 1 ELSE 0 END")), 'done']],
      where: { ...taskWhere, assignee_id: { [Op.ne]: null } },
      group: ['assignee_id'],
      include: [{ model: User, as: 'assignee', attributes: ['id','name','avatar_url'] }],
      raw: false,
    });

    // Tasks due in next 7 days
    const upcoming = await Task.findAll({
      where: {
        ...myTaskWhere,
        due_date: { [Op.between]: [new Date(), new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)] },
        status: { [Op.notIn]: ['done','cancelled'] },
      },
      include: [{ model: Project, as: 'project', attributes: ['id','name','emoji','color'] }],
      order: [['due_date','ASC']],
      limit: 5,
    });

    // Projects with progress
    const projectsWithProgress = await Promise.all(
      projectIds.slice(0, 6).map(async pid => {
        const [p, total, done] = await Promise.all([
          Project.findByPk(pid, { attributes: ['id','name','emoji','color','status'] }),
          Task.count({ where: { project_id: pid } }),
          Task.count({ where: { project_id: pid, status: 'done' } }),
        ]);
        return p ? { ...p.toJSON(), taskCount: total, doneCount: done, progress: total ? Math.round(done/total*100) : 0 } : null;
      })
    );

    res.json({
      stats: { totalTasks, doneTasks, inProgressTasks, todoTasks, overdueTasks, totalProjects, activeProjects, teamMembers, completionRate: totalTasks ? Math.round(doneTasks/totalTasks*100) : 0 },
      tasksByUser,
      recentActivity,
      upcomingTasks: upcoming,
      projectsProgress: projectsWithProgress.filter(Boolean),
    });
  } catch (err) { next(err); }
};

module.exports = { getDashboard };
