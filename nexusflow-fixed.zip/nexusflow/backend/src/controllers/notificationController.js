const { Notification } = require('../models');
const { Op } = require('sequelize');

const getNotifications = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, unread } = req.query;
    const where = { user_id: req.user.id };
    if (unread === 'true') where.is_read = false;

    const { count, rows: notifications } = await Notification.findAndCountAll({
      where,
      order: [['created_at', 'DESC']],
      limit: parseInt(limit),
      offset: (parseInt(page) - 1) * parseInt(limit),
    });

    const unreadCount = await Notification.count({ where: { user_id: req.user.id, is_read: false } });
    res.json({ notifications, total: count, unreadCount });
  } catch (err) { next(err); }
};

const markRead = async (req, res, next) => {
  try {
    const { ids } = req.body; // array of ids or 'all'
    if (ids === 'all') {
      await Notification.update({ is_read: true, read_at: new Date() }, { where: { user_id: req.user.id } });
    } else {
      await Notification.update({ is_read: true, read_at: new Date() }, { where: { id: { [Op.in]: ids }, user_id: req.user.id } });
    }
    res.json({ message: 'Marked as read' });
  } catch (err) { next(err); }
};

const deleteNotification = async (req, res, next) => {
  try {
    await Notification.destroy({ where: { id: req.params.id, user_id: req.user.id } });
    res.json({ message: 'Deleted' });
  } catch (err) { next(err); }
};

module.exports = { getNotifications, markRead, deleteNotification };
