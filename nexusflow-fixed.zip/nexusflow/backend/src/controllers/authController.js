const { User, Project, Task } = require('../models');
const { Op } = require('sequelize');

const getMe = async (req, res, next) => {
  try {
    const user = await User.findByPk(req.user.id, {
      attributes: { exclude: ['firebase_uid'] }
    });
    res.json({ user });
  } catch (err) { next(err); }
};

const updateProfile = async (req, res, next) => {
  try {
    const { name, notification_prefs } = req.body;
    const updates = {};
    if (name) updates.name = name;
    if (notification_prefs) updates.notification_prefs = notification_prefs;
    if (req.file) updates.avatar_url = `/uploads/${req.file.filename}`;

    await req.user.update(updates);
    res.json({ user: req.user, message: 'Profile updated' });
  } catch (err) { next(err); }
};

const getStats = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const [totalTasks, doneTasks, overdueTasks, inProgressTasks] = await Promise.all([
      Task.count({ where: { assignee_id: userId } }),
      Task.count({ where: { assignee_id: userId, status: 'done' } }),
      Task.count({
        where: { assignee_id: userId, due_date: { [Op.lt]: new Date() }, status: { [Op.notIn]: ['done', 'cancelled'] } }
      }),
      Task.count({ where: { assignee_id: userId, status: 'in_progress' } }),
    ]);
    res.json({ totalTasks, doneTasks, overdueTasks, inProgressTasks, completionRate: totalTasks ? Math.round(doneTasks / totalTasks * 100) : 0 });
  } catch (err) { next(err); }
};

const searchUsers = async (req, res, next) => {
  try {
    const { q } = req.query;
    if (!q || q.length < 2) return res.json({ users: [] });
    const users = await User.findAll({
      where: { [Op.or]: [{ name: { [Op.iLike]: `%${q}%` } }, { email: { [Op.iLike]: `%${q}%` } }] },
      attributes: ['id', 'name', 'email', 'avatar_url', 'role'],
      limit: 10,
    });
    res.json({ users });
  } catch (err) { next(err); }
};

module.exports = { getMe, updateProfile, getStats, searchUsers };
