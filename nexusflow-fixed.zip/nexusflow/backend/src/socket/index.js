const { admin } = require('../config/firebase');
const { User } = require('../models');

const setupSocket = (io) => {
  // Auth middleware for socket
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error('No token'));

      const decoded = await admin.auth().verifyIdToken(token);
      const user = await User.findOne({ where: { firebase_uid: decoded.uid } });
      if (!user) return next(new Error('User not found'));

      socket.user = user;
      next();
    } catch (err) {
      next(new Error('Auth failed'));
    }
  });

  io.on('connection', (socket) => {
    const user = socket.user;
    console.log(`🔌 Socket connected: ${user.name} (${user.id})`);

    // Join personal room
    socket.join(`user:${user.id}`);

    // Join project rooms
    socket.on('join:project', (projectId) => {
      socket.join(`project:${projectId}`);
      socket.to(`project:${projectId}`).emit('user:online', {
        userId: user.id, name: user.name, avatar: user.avatar_url
      });
    });

    socket.on('leave:project', (projectId) => {
      socket.leave(`project:${projectId}`);
    });

    // Real-time typing in task comments
    socket.on('typing:start', ({ taskId }) => {
      socket.to(`task:${taskId}`).emit('typing:start', { userId: user.id, name: user.name });
    });
    socket.on('typing:stop', ({ taskId }) => {
      socket.to(`task:${taskId}`).emit('typing:stop', { userId: user.id });
    });

    socket.on('join:task', (taskId) => socket.join(`task:${taskId}`));

    socket.on('disconnect', () => {
      console.log(`🔌 Socket disconnected: ${user.name}`);
      socket.broadcast.emit('user:offline', { userId: user.id });
    });
  });

  return io;
};

// Helper to emit task events
const emitTaskUpdate = (io, projectId, event, data) => {
  io.to(`project:${projectId}`).emit(event, data);
};

module.exports = { setupSocket, emitTaskUpdate };
